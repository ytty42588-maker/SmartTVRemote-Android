# Smart TV Remote (Android)

A phone app that connects to an Android/Android TV device over ADB TCP and provides:

- Remote controls (navigation, volume, media, app shortcuts)
- Touchpad-style TV touch input (tap and swipe; not a guaranteed hardware-style mouse cursor)
- On-screen phone keyboard text sending and navigation keys
- ADB shell terminal with output
- Installed-app list and app launching
- RAM information (what the TV exposes through shell commands)
- Logcat crash/error viewer
- Voice shortcuts (Hindi speech recognition where available)
- Saved IP:port and automatic reconnect attempt when the app opens

## Important connection limits

- The app includes an ADB client library (`dev.mobile:dadb`); a separate Termux/PC ADB installation is not required for the app itself.
- The TV must have ADB network debugging enabled and must authorize this app's ADB key.
- This build connects to the TV's ADB TCP endpoint (normally port `5555`). It does **not** implement Android 11+ Wireless Debugging QR/pairing-code flow. Pair the TV / enable TCP debugging using the TV's supported settings first.
- Automatic reconnect means retrying the previously saved IP:port. It cannot bypass TV authorization, a changed IP, Wi-Fi isolation, or a disabled ADB service.
- Touchpad uses Android shell `input tap` / `input swipe` at a 1920x1080 coordinate assumption. Some TVs use a different resolution or block touch injection. A real pointer cursor is device/firmware-dependent.
- The terminal runs commands on the connected TV. Only run commands you understand; incorrect commands can change TV settings or data.
- RAM and log visibility depend on Android version and shell permissions. Some system-app controls may be restricted.

## Build APK with GitHub Actions (phone-friendly)

1. Create/open a GitHub repository.
2. Upload the **contents** of this project folder to the repository root (the `.github` folder must also be uploaded). Do not upload the outer `TVRemote` folder as an extra nested level.
3. Open the repository's **Actions** tab. Enable Actions if GitHub asks.
4. Open workflow **build** and press **Run workflow** (or wait for the first push build).
5. Wait until the run shows a green check.
6. Open that run, scroll to **Artifacts**, and download `tvremote-apk`.
7. Extract the downloaded artifact ZIP. Install `app-debug.apk` on your Android phone. If Android asks, allow installation from the browser/files app you used.

The APK is a debug build for testing, not a Play Store release. Keep the GitHub repository private if you do not want to publish your source code.

## v2.0 (नया UI)

Tabs: Connect, Remote (D-pad, Vol/CH, media, numpad, hold-to-repeat), Pad (touchpad + keyboard),
Apps, RAM (live graph, storage, per-app bars, phone RAM/storage), Close (kill apps, cache),
Tools (TV shell, phone shell, logs, APK install, file push, URL download), Settings (6 colour themes, manual in Hindi).

## v2.1

- **Connect**: पहले port जाँचता है, Allow-popup पर 40 सेकंड timeout, साफ़ error, और **🩺 Diagnose** बटन।
- **Term टैब**: Termux जैसा terminal. फ़ोन का असली `sh` (cd, ls, ping...), built-in `adb connect/devices/shell/install/push/logcat`, `wget`/`curl`/`download`, history, Tab, ^C.
- हर बटन दबाने पर रंग बदलता है और थोड़ा छोटा होता है; छोड़ने पर वापस।
- सीमा: dadb 1.2.7 Android 11+ के Wireless-debugging (TLS) port और `adb pair` को नहीं समझता; वहाँ Termux से एक बार `adb tcpip 5555` करो।
