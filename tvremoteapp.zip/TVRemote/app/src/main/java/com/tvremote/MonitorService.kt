package com.tvremote

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** ऐप background में जाए या स्क्रीन बंद हो, तब भी निगरानी (Auto-Guard) को ज़िंदा रखता है। */
class MonitorService : Service() {
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        makeChannels(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH_SVC) else Notification.Builder(this))
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("🛡 TV निगरानी चालू")
            .setContentText("गर्मी, RAM और स्टोरेज पर नज़र है")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(1, n)
        if (wl == null) {
            wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tvremote:guard").apply { acquire() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { wl?.release() } catch (_: Exception) {}
        wl = null
        super.onDestroy()
    }

    companion object {
        const val CH_SVC = "guard_svc"
        const val CH_ALERT = "guard_alert"

        fun makeChannels(c: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH_SVC, "निगरानी चालू", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_ALERT, "TV अलर्ट", NotificationManager.IMPORTANCE_HIGH))
        }
    }
}
