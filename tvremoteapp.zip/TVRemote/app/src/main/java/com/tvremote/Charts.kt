package com.tvremote

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

class LineChartView(ctx: Context) : View(ctx) {
    var data: List<Float> = emptyList()
        set(v) { field = v; invalidate() }
    var lineColor: Int = Color.CYAN
    var gridColor: Int = Color.argb(50, 136, 136, 136)
    var maxPoints: Int = 40

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint().apply { strokeWidth = 2f }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        grid.color = gridColor
        for (i in 1..3) {
            val y = h * i / 4f
            canvas.drawLine(0f, y, w, y, grid)
        }
        val n = data.size
        if (n < 2) return
        val step = w / (maxPoints - 1).toFloat()
        val path = Path()
        val fill = Path()
        for (i in 0 until n) {
            val x = w - (n - 1 - i) * step
            val y = h - (data[i].coerceIn(0f, 100f) / 100f) * h
            if (i == 0) {
                path.moveTo(x, y); fill.moveTo(x, h); fill.lineTo(x, y)
            } else {
                path.lineTo(x, y); fill.lineTo(x, y)
            }
        }
        fill.lineTo(w, h)
        fill.close()
        line.color = lineColor
        fillPaint.color = Color.argb(60, Color.red(lineColor), Color.green(lineColor), Color.blue(lineColor))
        canvas.drawPath(fill, fillPaint)
        canvas.drawPath(path, line)
    }
}

class BarView(ctx: Context) : View(ctx) {
    var fraction: Float = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var fillColor: Int = Color.CYAN
    var trackColor: Int = Color.argb(50, 136, 136, 136)

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        p.color = trackColor
        canvas.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        if (fraction > 0f) {
            p.color = fillColor
            canvas.drawRoundRect(RectF(0f, 0f, maxOf(w * fraction, h), h), r, r, p)
        }
    }
}
