package com.tvremote

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class A(val words: List<String>, val pkgs: List<String>)

val APPS = mapOf(
    "youtube" to A(listOf("youtube", "यूट्यूब", "यू ट्यूब"), listOf("com.google.android.youtube.tv", "com.google.android.youtube")),
    "netflix" to A(listOf("netflix", "नेटफ्लिक्स"), listOf("com.netflix.ninja", "com.netflix.mediaclient")),
    "prime" to A(listOf("prime", "प्राइम", "amazon", "अमेज़न"), listOf("com.amazon.amazonvideo.livingroom", "com.amazon.avod.thirdpartyclient", "com.amazon.avod")),
    "hotstar" to A(listOf("hotstar", "हॉटस्टार", "disney", "डिज़्नी"), listOf("in.startv.hotstar", "in.startv.hotstar.dplus.tv")),
    "chrome" to A(listOf("chrome", "क्रोम"), listOf("com.android.chrome")),
    "browser" to A(listOf("browser", "ब्राउज़र", "ब्राउजर"), listOf("com.android.browser")),
    "settings" to A(listOf("settings", "सेटिंग"), listOf("com.android.settings"))
)

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private var dadb: Dadb? = null
    private val prefs by lazy { getSharedPreferences("tv", MODE_PRIVATE) }
    private val installed = linkedSetOf<String>()
    private var thirdParty = listOf<String>()
    private var current = "remote"
    private val pages = LinkedHashMap<String, View>()
    private lateinit var status: TextView
    private lateinit var ipBox: EditText
    private lateinit var inputBox: EditText
    private lateinit var search: EditText
    private lateinit var appList: LinearLayout
    private lateinit var ramInfo: TextView
    private lateinit var ramList: LinearLayout
    private lateinit var logView: TextView
    private lateinit var terminalInput: EditText
    private lateinit var terminalOutput: TextView
    private lateinit var keyboardInput: EditText
    private lateinit var mousePad: View
    private var mouseStartX = 0f
    private var mouseStartY = 0f
    private var mouseLastX = 0f
    private var mouseLastY = 0f
    private var mouseMoved = false

    private val ramLoop = object : Runnable {
        override fun run() {
            if (current == "ram") { refreshRam(); ui.postDelayed(this, 8000) }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = col().apply { setPadding(20, 20, 20, 20); setBackgroundColor(Color.parseColor("#111111")) }
        status = tv("स्थिति: जुड़ा नहीं")
        ipBox = edit("TV IP:Port (जैसे 10.84.140.33:5555)").apply { setText(prefs.getString("ip", "")) }
        root.addView(status)
        root.addView(ipBox)
        root.addView(row(btn("Connect") { connectClicked() }, btn("Scan") { scan() }))
        root.addView(row(btn("Remote") { show("remote") }, btn("Mouse") { show("mouse") },
            btn("Keyboard") { show("keyboard") }))
        root.addView(row(btn("Apps") { show("apps") }, btn("RAM") { show("ram") },
            btn("Logs") { show("logs") }, btn("Terminal") { show("terminal") }, btn("🎤") { listen() }))

        val remote = col(); val apps = col(); val ram = col(); val logs = col()
        val mouse = col(); val keyboard = col(); val terminal = col()
        pages["remote"] = remote; pages["apps"] = apps; pages["ram"] = ram; pages["logs"] = logs
        pages["mouse"] = mouse; pages["keyboard"] = keyboard; pages["terminal"] = terminal
        buildRemote(remote)

        search = edit("ऐप खोजो")
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { renderApps() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        appList = col()
        apps.addView(row(btn("Refresh") { loadApps() }))
        apps.addView(search)
        apps.addView(appList)

        ramInfo = tv("RAM: ...")
        ramList = col()
        ram.addView(ramInfo)
        ram.addView(tv("ऐप पर टैप = उसे बंद करो"))
        ram.addView(ramList)

        logView = tv("").apply { typeface = Typeface.MONOSPACE; textSize = 11f; setTextIsSelectable(true) }
        logs.addView(row(btn("Crash") { showLogs("crash") }, btn("Errors") { showLogs("err") }, btn("All") { showLogs("all") }))
        logs.addView(logView)

        mouse.addView(tv("Touchpad: टैप/ड्रैग TV पर भेजें। Cursor दिखना TV के सपोर्ट पर निर्भर है।"))
        mousePad = TextView(this).apply {
            text = "यहाँ उंगली चलाएँ\nTap = क्लिक • Drag = स्वाइप"
            gravity = android.view.Gravity.CENTER
            textSize = 19f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#263238"))
            layoutParams = LinearLayout.LayoutParams(-1, 520)
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { mouseStartX=e.x; mouseStartY=e.y; mouseLastX=e.x; mouseLastY=e.y; mouseMoved=false; true }
                    MotionEvent.ACTION_MOVE -> { if (kotlin.math.abs(e.x-mouseStartX)+kotlin.math.abs(e.y-mouseStartY)>18) mouseMoved=true; mouseLastX=e.x; mouseLastY=e.y; true }
                    MotionEvent.ACTION_UP -> {
                        val w=mousePad.width.coerceAtLeast(1).toFloat(); val h=mousePad.height.coerceAtLeast(1).toFloat()
                        val x1=(mouseStartX/w*1920).toInt().coerceIn(0,1919); val y1=(mouseStartY/h*1080).toInt().coerceIn(0,1079)
                        val x2=(mouseLastX/w*1920).toInt().coerceIn(0,1919); val y2=(mouseLastY/h*1080).toInt().coerceIn(0,1079)
                        if (mouseMoved) sh("input swipe $x1 $y1 $x2 $y2 350") else sh("input tap $x1 $y1")
                        true
                    }
                    else -> true
                }
            }
        }
        mouse.addView(mousePad)
        mouse.addView(row(btn("Back") { key(4) }, btn("Home") { key(3) }, btn("OK / Click") { key(66) }))
        mouse.addView(row(btn("▲") { key(19) }, btn("▼") { key(20) }, btn("◀") { key(21) }, btn("▶") { key(22) }))

        keyboard.addView(tv("मोबाइल कीबोर्ड से लिखें और TV पर भेजें"))
        keyboardInput = edit("यहाँ टाइप करें")
        keyboard.addView(keyboardInput)
        keyboard.addView(row(btn("Send Text") { sendKeyboardText() }, btn("Enter") { key(66) }, btn("Backspace") { key(67) }))
        keyboard.addView(row(btn("Space") { key(62) }, btn("Tab") { key(61) }, btn("Esc") { key(111) }))
        keyboard.addView(row(btn("↑") { key(19) }, btn("↓") { key(20) }, btn("←") { key(21) }, btn("→") { key(22) }))

        terminal.addView(tv("ADB Shell Terminal — कमांड TV पर चलती है, मोबाइल पर नहीं। सावधानी से इस्तेमाल करें।"))
        terminalInput = edit("उदाहरण: wm size")
        terminal.addView(terminalInput)
        terminal.addView(row(btn("Run") { runTerminal() }, btn("Clear") { terminalOutput.text = "" }, btn("Screen Info") { terminalInput.setText("wm size; wm density; getprop ro.build.version.release") }))
        terminalOutput = tv("आउटपुट यहाँ दिखेगा").apply { typeface=Typeface.MONOSPACE; textSize=12f; setTextIsSelectable(true) }
        terminal.addView(terminalOutput)

        pages.values.forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
        show("remote")

        val saved = prefs.getString("ip", "") ?: ""
        if (saved.isNotEmpty()) io.execute { connect(saved) }
    }

    private fun buildRemote(r: LinearLayout) {
        r.addView(row(kb("Power", 26), kb("Source", 178), kb("Display", 165)))
        r.addView(row(app("YouTube", "youtube"), app("Netflix", "netflix"), app("Prime", "prime"), app("Hotstar", "hotstar")))
        r.addView(row(kb("Menu", 82), kb("Home", 3), kb("Setting", 176), app("Browser", "browser")))
        r.addView(row(gap(), kb("▲", 19), gap()))
        r.addView(row(kb("◀", 21), kb("OK", 66), kb("▶", 22)))
        r.addView(row(gap(), kb("▼", 20), gap()))
        r.addView(row(kb("Back", 4), kb("Vol+", 24), kb("CH+", 166)))
        r.addView(row(kb("Mute", 164), kb("Vol-", 25), kb("CH-", 167)))
        r.addView(row(kb("⏪", 89), kb("⏯", 85), kb("⏹", 86), kb("⏩", 90)))
        r.addView(row(kb("R", 183, "#c62828"), kb("G", 184, "#2e7d32"), kb("Y", 185, "#f9a825"), kb("B", 186, "#1565c0")))
        r.addView(row(kb("1", 8), kb("2", 9), kb("3", 10)))
        r.addView(row(kb("4", 11), kb("5", 12), kb("6", 13)))
        r.addView(row(kb("7", 14), kb("8", 15), kb("9", 16)))
        r.addView(row(gap(), kb("0", 7), gap()))
        inputBox = edit("text या URL")
        r.addView(inputBox)
        r.addView(row(btn("Type") { typeText() }, btn("Open URL") { openUrl() }))
    }

    // ---------- UI helpers ----------
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun tv(s: String) = TextView(this).apply { text = s; setTextColor(Color.WHITE); textSize = 15f }
    private fun edit(h: String) = EditText(this).apply {
        hint = h; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
    }
    private fun gap() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 10, 1f) }
    private fun btn(label: String, f: () -> Unit) = Button(this).apply {
        text = label; textSize = 15f; isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(0, 150, 1f)
        setOnClickListener { f() }
    }
    private fun kb(label: String, code: Int, color: String? = null) = btn(label) { key(code) }.apply {
        if (color != null) setBackgroundColor(Color.parseColor(color))
    }
    private fun app(label: String, id: String) = btn(label) { launchAlias(id) }
    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }
    private fun say(s: String) { ui.post { status.text = "स्थिति: $s" } }

    private fun show(name: String) {
        current = name
        pages.forEach { (k, v) -> v.visibility = if (k == name) View.VISIBLE else View.GONE }
        ui.removeCallbacks(ramLoop)
        if (name == "ram") ui.post(ramLoop)
        if (name == "apps") loadApps()
    }

    // ---------- ADB ----------
    private fun keys(): AdbKeyPair {
        val pr = File(filesDir, "adbkey")
        val pu = File(filesDir, "adbkey.pub")
        if (!pr.exists() || !pu.exists()) AdbKeyPair.generate(pr, pu)
        return AdbKeyPair.read(pr, pu)
    }

    private fun connect(ip: String): Boolean {
        try { dadb?.close() } catch (_: Exception) {}
        dadb = null
        say("जोड़ रहा हूँ...")
        return try {
            val host = ip.substringBeforeLast(':', ip)
            val port = ip.substringAfterLast(':', "5555").toIntOrNull() ?: 5555
            val d = Dadb.create(host, port, keys())
            d.shell("echo ok")
            dadb = d
            say("जुड़ गया: $ip")
            loadApps(false)
            true
        } catch (e: Exception) {
            say("नहीं जुड़ा: ${e.message ?: e.javaClass.simpleName}")
            false
        }
    }

    private fun connectClicked() {
        val ip = ipBox.text.toString().trim()
        if (ip.isEmpty()) { say("पहले IP डालो या Scan दबाओ"); return }
        prefs.edit().putString("ip", ip).apply()
        io.execute { connect(ip) }
    }

    private fun sh(cmd: String, cb: ((String) -> Unit)? = null) = io.execute {
        fun exec(): String { val r = dadb!!.shell(cmd); return r.output + r.errorOutput }
        var out: String? = null
        try { out = exec() } catch (e: Exception) {
            val ip = prefs.getString("ip", "") ?: ""
            if (ip.isNotEmpty() && connect(ip)) {
                try { out = exec() } catch (_: Exception) { say("कमांड फेल") }
            }
        }
        val o = out
        if (cb != null && o != null) ui.post { cb(o) }
    }

    private fun key(code: Int) = sh("input keyevent $code")
    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun typeText() {
        val t = inputBox.text.toString()
        if (t.isEmpty()) return
        sh("input text " + q(t.replace(" ", "%s")))
        inputBox.setText("")
    }

    private fun openUrl() {
        var u = inputBox.text.toString().trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http")) u = "http://$u"
        sh("am start -a android.intent.action.VIEW -d " + q(u))
    }

    // ---------- Keyboard and terminal ----------
    private fun sendKeyboardText() {
        val value=keyboardInput.text.toString()
        if (value.isBlank()) return
        sh("input text " + q(value.replace(" ", "%s")))
        keyboardInput.setText("")
    }
    private fun runTerminal() {
        val command=terminalInput.text.toString().trim()
        if (command.isBlank()) return
        sh(command) { result -> terminalOutput.text = "\$ $command\n$result" }
    }

    // ---------- Apps ----------
    private fun launch(pkg: String) {
        say("खोल रहा हूँ: $pkg")
        sh("monkey -p $pkg -c android.intent.category.LAUNCHER 1") {
            if (it.contains("No activities")) sh("monkey -p $pkg -c android.intent.category.LEANBACK_LAUNCHER 1") { r ->
                if (r.contains("No activities")) say("ऐप नहीं मिला: $pkg")
            }
        }
    }

    private fun launchAlias(id: String) {
        val a = APPS[id] ?: return
        launch(a.pkgs.firstOrNull { it in installed } ?: a.pkgs.first())
    }

    private fun loadApps(render: Boolean = true) =
        sh("pm list packages -3; echo ---; pm list packages") { out ->
            val parts = out.split("---")
            fun pk(s: String) = s.lines().map { it.trim().removePrefix("package:") }.filter { it.isNotEmpty() }
            thirdParty = pk(parts[0])
            installed.clear()
            installed.addAll(pk(parts.getOrElse(1) { "" }))
            if (render) renderApps()
        }

    private fun renderApps() {
        appList.removeAllViews()
        val f = search.text.toString().trim().lowercase()
        val extra = installed.filter { p -> listOf("browser", "chrome", "settings").any { p.contains(it) } }
        for (p in (thirdParty + extra).distinct().filter { f.isEmpty() || it.lowercase().contains(f) }) {
            appList.addView(Button(this).apply {
                text = p; isAllCaps = false
                setOnClickListener { launch(p) }
            })
        }
    }

    // ---------- RAM ----------
    private fun refreshRam() = sh("cat /proc/meminfo; echo ===; dumpsys meminfo") { out ->
        val parts = out.split("===")
        fun mb(k: String) = Regex("$k:\\s+(\\d+)").find(parts[0])?.groupValues?.get(1)?.toLong()?.div(1024) ?: 0L
        ramInfo.text = "RAM कुल ${mb("MemTotal")} MB | खाली ${mb("MemFree")} MB | Cached ${mb("Cached")} MB"
        ramList.removeAllViews()
        val rx = Regex("^\\s*([\\d,]+)\\s*[kK]B?:\\s+(\\S+)\\s+\\(pid", RegexOption.MULTILINE)
        val rows = rx.findAll(parts.getOrElse(1) { "" })
            .map { it.groupValues[1].replace(",", "").toLong() / 1024 to it.groupValues[2] }
            .distinctBy { it.second }.take(12).toList()
        if (rows.isEmpty()) ramList.addView(tv("dumpsys पढ़ नहीं पाया"))
        for ((m, n) in rows) ramList.addView(Button(this).apply {
            text = "$m MB  $n"; isAllCaps = false
            setOnClickListener {
                val p = n.substringBefore(':')
                if (p.contains('.')) { sh("am force-stop $p"); say("बंद किया: $p") }
            }
        })
    }

    // ---------- Logs ----------
    private fun showLogs(mode: String) = sh("logcat -d -v time -t 1500") { out ->
        val l = out.lines()
        val f = when (mode) {
            "crash" -> l.filter { it.contains("FATAL EXCEPTION") || it.contains("AndroidRuntime") || it.contains("ANR in") || it.contains("has died") }
            "err" -> l.filter { it.contains(" E/") }
            else -> l
        }
        logView.text = f.takeLast(80).joinToString("\n").ifEmpty { "कुछ नहीं मिला" }
    }

    // ---------- Voice ----------
    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        try { startActivityForResult(i, 7) } catch (e: Exception) { say("वॉइस सपोर्ट नहीं मिला") }
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == 7 && c == RESULT_OK) {
            d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { voice(it) }
        }
    }

    private fun voice(text: String) {
        val t = text.lowercase()
        say("सुना: $text")
        val cmds = listOf(
            listOf("volume up", "वॉल्यूम बढ़ा", "आवाज़ बढ़ा", "आवाज बढ़ा") to 24,
            listOf("volume down", "वॉल्यूम कम", "आवाज़ कम", "आवाज कम") to 25,
            listOf("mute", "म्यूट") to 164,
            listOf("home", "होम") to 3,
            listOf("back", "पीछे", "वापस") to 4
        )
        cmds.firstOrNull { (w, _) -> w.any { t.contains(it) } }?.let { key(it.second); return }
        APPS.entries.firstOrNull { (_, a) -> a.words.any { t.contains(it) } }?.let { launchAlias(it.key); return }
        val hit = installed.firstOrNull { t.contains(it.substringAfterLast('.').lowercase()) }
        if (hit != null) launch(hit) else say("समझ नहीं आया: $text")
    }

    // ---------- Scan ----------
    private fun scan() {
        say("TV ढूँढ रहा हूँ...")
        io.execute {
            val prefixes = NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.interfaceAddresses }
                .mapNotNull { (it.address as? Inet4Address)?.takeIf { a -> !a.isLoopbackAddress }?.hostAddress }
                .map { it.substringBeforeLast('.') }
                .distinct()
            val found = ConcurrentLinkedQueue<String>()
            val pool = Executors.newFixedThreadPool(64)
            for (p in prefixes) for (i in 1..254) pool.execute {
                val h = "$p.$i"
                try {
                    Socket().use { it.connect(InetSocketAddress(h, 5555), 400) }
                    found.add(h)
                } catch (_: Exception) {}
            }
            pool.shutdown()
            pool.awaitTermination(30, TimeUnit.SECONDS)
            val ip = found.firstOrNull()
            if (ip == null) {
                say("TV नहीं मिला। हॉटस्पॉट ON है? ADB ENABLE ON है?")
            } else {
                prefs.edit().putString("ip", ip).apply()
                ui.post { ipBox.setText(ip) }
                connect(ip)
            }
        }
    }
}
