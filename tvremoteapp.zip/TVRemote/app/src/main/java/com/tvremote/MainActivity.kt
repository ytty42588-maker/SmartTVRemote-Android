package com.tvremote

import android.app.Activity
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

class A(val words: List<String>, val pkgs: List<String>)

val APPS = mapOf(
    "youtube" to A(listOf("youtube", "यूट्यूब", "यू ट्यूब"), listOf("com.google.android.youtube.tv", "com.google.android.youtube")),
    "netflix" to A(listOf("netflix", "नेटफ्लिक्स"), listOf("com.netflix.ninja", "com.netflix.mediaclient")),
    "prime" to A(listOf("prime", "प्राइम", "amazon", "अमेज़न"), listOf("com.amazon.amazonvideo.livingroom", "com.amazon.avod.thirdpartyclient", "com.amazon.avod")),
    "hotstar" to A(listOf("hotstar", "हॉटस्टार", "disney", "डिज़्नी"), listOf("in.startv.hotstar", "in.startv.hotstar.dplus.tv")),
    "chrome" to A(listOf("chrome", "क्रोम"), listOf("com.android.chrome")),
    "browser" to A(listOf("browser", "ब्राउज़र", "ब्राउजर"), listOf("com.android.browser")),
    "settings" to A(listOf("settings", "सेटिंग"), listOf("com.android.settings"))
)

data class Palette(
    val name: String, val bg: Int, val card: Int, val text: Int, val sub: Int,
    val accent: Int, val btn: Int, val btnText: Int, val light: Boolean = false
)

fun hex(s: String): Int = Color.parseColor(s)

val PALETTES = listOf(
    Palette("Black", hex("#0B0B0F"), hex("#17171F"), hex("#FFFFFF"), hex("#9AA0A6"), hex("#00E5FF"), hex("#262633"), hex("#FFFFFF")),
    Palette("White", hex("#F1F3F8"), hex("#FFFFFF"), hex("#111827"), hex("#6B7280"), hex("#2563EB"), hex("#E5E7EB"), hex("#111827"), true),
    Palette("Red", hex("#140808"), hex("#241010"), hex("#FFFFFF"), hex("#C9A0A0"), hex("#FF3B30"), hex("#3D1818"), hex("#FFFFFF")),
    Palette("Blue", hex("#07111F"), hex("#0E2038"), hex("#FFFFFF"), hex("#9DB4D3"), hex("#3D8BFF"), hex("#173560"), hex("#FFFFFF")),
    Palette("Green", hex("#06140C"), hex("#0D2417"), hex("#FFFFFF"), hex("#9CC7AC"), hex("#2ECC71"), hex("#164028"), hex("#FFFFFF")),
    Palette("Purple", hex("#100818"), hex("#1D1030"), hex("#FFFFFF"), hex("#B9A3D6"), hex("#B26BFF"), hex("#30194D"), hex("#FFFFFF"))
)

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private val poll = Executors.newSingleThreadExecutor()
    private val bg = Executors.newCachedThreadPool()
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var dadb: Dadb? = null
    private val prefs by lazy { getSharedPreferences("tv", MODE_PRIVATE) }

    private var pal = PALETTES[0]
    private val installed = linkedSetOf<String>()
    private var thirdParty = listOf<String>()
    private var current = "remote"
    private val pages = LinkedHashMap<String, View>()
    private val tabViews = LinkedHashMap<String, TextView>()
    private var connected = false
    private var tvName = ""
    private var tvW = 1920
    private var tvH = 1080
    private val ramHistory = ArrayList<Float>()
    private var topProcs: List<Pair<Long, String>> = emptyList()
    private val termSpan = android.text.SpannableStringBuilder()
    private var cwd = ""
    private var tvCwd = "/"
    private var inTv = false
    private val history = ArrayList<String>()
    private var histPos = 0
    @Volatile private var busy = false
    @Volatile private var localProc: Process? = null
    @Volatile private var localIn: java.io.OutputStream? = null
    @Volatile private var lastError = ""
    @Volatile private var fatal = false
    private var ramTick = 0

    private lateinit var topStatus: TextView
    private lateinit var connStatus: TextView
    private lateinit var connInfo: TextView
    private lateinit var ipBox: EditText
    private lateinit var inputBox: EditText
    private lateinit var kbInput: EditText
    private lateinit var search: EditText
    private lateinit var appList: LinearLayout
    private lateinit var ramBig: TextView
    private lateinit var ramSub: TextView
    private lateinit var ramChart: LineChartView
    private lateinit var ramApps: LinearLayout
    private lateinit var storTv: TextView
    private lateinit var storBar: BarView
    private lateinit var phoneRam: TextView
    private lateinit var phoneRamBar: BarView
    private lateinit var phoneStor: TextView
    private lateinit var phoneStorBar: BarView
    private lateinit var closeList: LinearLayout
    private lateinit var termOut: TextView
    private lateinit var termScroll: ScrollView
    private lateinit var termIn: EditText
    private lateinit var termPrompt: TextView
    private lateinit var diagOut: TextView
    private lateinit var padMouse: LinearLayout
    private lateinit var padKeys: LinearLayout
    private lateinit var touch: TextView
    private var mx0 = 0f
    private var my0 = 0f
    private var mx1 = 0f
    private var my1 = 0f
    private var moved = false

    private val ramLoop = object : Runnable {
        override fun run() {
            if (current == "ram") {
                ramTick++
                pollRam(ramTick % 4 == 1)
                ui.postDelayed(this, 2500)
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pal = PALETTES.firstOrNull { it.name == prefs.getString("theme", "Black") } ?: PALETTES[0]
        if (prefs.getBoolean("awake", true)) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cwd = File(filesDir, "home").apply { mkdirs() }.path
        termLine("Smart TV Remote Terminal — 'help' लिखकर देखो", C_DIM)
        buildUi()
        val saved = prefs.getString("ip", "") ?: ""
        if (saved.isNotEmpty() && prefs.getBoolean("auto", true)) io.execute { connectRetry(saved) }
    }

    override fun onDestroy() {
        try { dadb?.close() } catch (_: Exception) {}
        try { localProc?.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }

    // ================= UI helpers =================
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val onAccent: Int
        get() {
            val a = pal.accent
            val l = (0.299 * Color.red(a) + 0.587 * Color.green(a) + 0.114 * Color.blue(a)) / 255.0
            return if (l > 0.6) Color.BLACK else Color.WHITE
        }

    private fun shape(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun oval(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) * (1 - t) + Color.red(b) * t).toInt(),
        (Color.green(a) * (1 - t) + Color.green(b) * t).toInt(),
        (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
    )

    private fun pressedOf(c: Int): Int =
        if (c == pal.accent) mix(c, if (pal.light) Color.BLACK else Color.WHITE, 0.40f)
        else mix(c, pal.accent, 0.55f)

    // दबाने पर रंग बदलता है, छोड़ने पर वापस
    private fun ripple(color: Int, r: Int) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), shape(pressedOf(color), r))
        addState(intArrayOf(), shape(color, r))
    }

    private fun ovalPress(color: Int) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), oval(pressedOf(color)))
        addState(intArrayOf(), oval(color))
    }

    private fun fx(v: View, down: Boolean) {
        v.animate().cancel()
        if (down) v.animate().scaleX(0.88f).scaleY(0.88f).alpha(0.7f).setDuration(70).start()
        else v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(140).start()
    }

    @Suppress("ClickableViewAccessibility")
    private fun View.pressFx() {
        setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> fx(view, true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> fx(view, false)
            }
            false
        }
    }

    private fun buzz(v: View) {
        if (prefs.getBoolean("haptic", true)) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copy(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("tv", s))
        toast("कॉपी हो गया")
    }

    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    private fun label(s: String, size: Float = 15f, color: Int = pal.text, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun title(s: String) = label(s, 13f, pal.accent, true).apply {
        setPadding(dp(4), dp(2), 0, dp(6))
    }

    private fun card(): LinearLayout = col().apply {
        background = shape(pal.card, 18)
        setPadding(dp(12), dp(12), dp(12), dp(10))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }

    private fun edit(h: String) = EditText(this).apply {
        hint = h; setTextColor(pal.text); setHintTextColor(pal.sub)
        background = shape(pal.btn, 12)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        textSize = 15f
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }

    private fun pill(
        label: String, bgc: Int = pal.btn, fg: Int = pal.btnText, h: Int = 50, size: Float = 15f,
        f: (View) -> Unit
    ): TextView = TextView(this).apply {
        text = label; textSize = size; setTextColor(fg); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = ripple(bgc, 14)
        layoutParams = LinearLayout.LayoutParams(0, dp(h), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        setOnClickListener { buzz(it); f(it) }
        pressFx()
    }

    private fun mini(label: String, bgc: Int = pal.btn, fg: Int = pal.btnText, f: (View) -> Unit): TextView =
        TextView(this).apply {
            text = label; textSize = 13f; setTextColor(fg); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = ripple(bgc, 10)
            setPadding(dp(14), 0, dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
            setOnClickListener { buzz(it); f(it) }
            pressFx()
        }

    private fun colOf(vararg v: View, h: Int = 54) = col().apply {
        v.forEach {
            it.layoutParams = LinearLayout.LayoutParams(-1, dp(h)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            addView(it)
        }
    }

    private fun holdListener(code: Int) = View.OnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                v.isPressed = true
                fx(v, true)
                buzz(v)
                key(code)
                val r = object : Runnable {
                    override fun run() { key(code); ui.postDelayed(this, 220) }
                }
                v.tag = r
                ui.postDelayed(r, 450)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                (v.tag as? Runnable)?.let { ui.removeCallbacks(it) }
                v.tag = null
                v.isPressed = false
                fx(v, false)
            }
        }
        true
    }

    private fun keyPill(
        label: String, code: Int, bgc: Int = pal.btn, fg: Int = pal.btnText,
        hold: Boolean = false, h: Int = 50, size: Float = 15f
    ): TextView {
        val v = pill(label, bgc, fg, h, size) { key(code) }
        if (hold) v.setOnTouchListener(holdListener(code))
        return v
    }

    private fun appPill(label: String, id: String, color: String) =
        pill(label, Color.parseColor(color), Color.WHITE, 46, 13f) { launchAlias(id) }

    private fun scroll(inner: LinearLayout): ScrollView {
        inner.setPadding(dp(12), dp(12), dp(12), dp(80))
        return ScrollView(this).apply { addView(inner) }
    }

    // ================= Main UI =================
    private fun buildUi() {
        pages.clear(); tabViews.clear()
        window.statusBarColor = pal.card
        window.navigationBarColor = pal.card
        window.decorView.systemUiVisibility = if (pal.light) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
        }
        root.addView(topBar())
        root.addView(bottomNav())
        val frame = FrameLayout(this)
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        pages["connect"] = scroll(pageConnect())
        pages["remote"] = scroll(pageRemote())
        pages["pad"] = scroll(pagePad())
        pages["apps"] = scroll(pageApps())
        pages["ram"] = scroll(pageRam())
        pages["close"] = scroll(pageClose())
        pages["term"] = pageTerm()
        pages["tools"] = scroll(pageTools())
        pages["settings"] = scroll(pageSettings())
        pages.values.forEach { frame.addView(it, FrameLayout.LayoutParams(-1, -1)) }

        setContentView(root)
        termOut.text = termSpan
        refreshPrompt()
        refreshConnectCard()
        show(current)
    }

    private fun topBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(12), dp(10))
            setBackgroundColor(pal.card)
        }
        val t = col()
        t.addView(label("📺 Smart TV Remote", 18f, pal.text, true))
        topStatus = label(if (connected) "● जुड़ा हुआ" else "○ जुड़ा नहीं", 12f, if (connected) Color.parseColor("#4CAF50") else pal.sub)
        t.addView(topStatus)
        bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        val mic = TextView(this).apply {
            text = "🎤"; textSize = 20f; gravity = Gravity.CENTER
            background = ovalPress(pal.btn)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
            setOnClickListener { buzz(it); listen() }
            pressFx()
        }
        bar.addView(mic)
        return bar
    }

    private fun bottomNav(): View {
        val defs = listOf(
            Triple("connect", "🔌", "Connect"), Triple("remote", "🎮", "Remote"),
            Triple("pad", "🖱", "Pad"), Triple("apps", "📱", "Apps"),
            Triple("ram", "📊", "RAM"), Triple("close", "🧹", "Close"),
            Triple("term", "⌨", "Term"), Triple("tools", "💻", "Tools"), Triple("settings", "⚙", "Settings")
        )
        val rowv = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((id, icon, name) in defs) {
            val tab = TextView(this).apply {
                text = "$icon\n$name"; textSize = 14f; gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                layoutParams = LinearLayout.LayoutParams(dp(88), -2)
                setOnClickListener { buzz(it); show(id) }
                pressFx()
            }
            tabViews[id] = tab
            rowv.addView(tab)
        }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(pal.card)
            addView(rowv)
        }
    }

    private fun show(name: String) {
        current = name
        pages.forEach { (k, v) -> v.visibility = if (k == name) View.VISIBLE else View.GONE }
        tabViews.forEach { (k, v) ->
            v.setTextColor(if (k == name) pal.accent else pal.sub)
            v.typeface = if (k == name) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        ui.removeCallbacks(ramLoop)
        if (name == "ram") { ramTick = 0; ui.post(ramLoop); refreshPhone() }
        if (name == "apps") loadApps()
        if (name == "close") refreshTop()
        if (name == "term") refreshPrompt()
    }

    // ================= Pages =================
    private fun pageConnect(): LinearLayout {
        val p = col()
        val c1 = card()
        connStatus = label("🔴 जुड़ा नहीं", 22f, pal.text, true)
        connInfo = label("", 13f, pal.sub)
        c1.addView(connStatus); c1.addView(connInfo)
        p.addView(c1)

        val c2 = card()
        c2.addView(title("TV का IP:Port"))
        ipBox = edit("जैसे 192.168.1.20:5555")
        ipBox.setText(prefs.getString("ip", ""))
        ipBox.inputType = InputType.TYPE_CLASS_TEXT
        c2.addView(ipBox)
        c2.addView(row(
            pill("Connect", pal.accent, onAccent) { connectClicked() },
            pill("Scan") { scan() },
            pill("Disconnect") { disconnect() }
        ))
        c2.addView(row(
            pill("🔧 Fix Connection", h = 46, size = 13f) { fixConnection() },
            pill("🔑 Reset Key", h = 46, size = 13f) { resetKey() }
        ))
        c2.addView(row(
            pill("🩺 Diagnose (क्यों नहीं जुड़ा)", h = 46, size = 13f) { diagnose() },
            pill("⌨ Terminal", h = 46, size = 13f) { show("term") }
        ))
        p.addView(c2)

        val cd = card()
        cd.addView(title("🩺 जाँच का नतीजा"))
        diagOut = label("Diagnose दबाओ — बताएगा कि TV तक रास्ता है या नहीं, और port खुला है या नहीं।", 13f, pal.sub).apply {
            typeface = Typeface.MONOSPACE; setTextIsSelectable(true)
        }
        cd.addView(diagOut)
        p.addView(cd)

        val c2b = card()
        c2b.addView(title("अटक जाए / 'offline' दिखे तो (Termux)"))
        val fixCmds = "adb disconnect\nadb kill-server\nadb connect IP:5555\nadb devices"
        c2b.addView(label(fixCmds, 13f, pal.text).apply {
            typeface = Typeface.MONOSPACE
            background = shape(pal.btn, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setTextIsSelectable(true)
        })
        c2b.addView(label("पहली बार 'failed to connect' आए तो connect एक बार फिर चलाओ। 'device' दिखे तो जुड़ गया; 'offline' दिखे तो TV में USB debugging OFF→ON करो।", 12f, pal.sub).apply { setPadding(dp(4), dp(8), dp(4), 0) })
        c2b.addView(row(pill("Commands कॉपी", h = 44) { copy(fixCmds) }))
        p.addView(c2b)

        val c3 = card()
        c3.addView(title("Termux से जोड़ना (Android 11+ / Wireless debugging) — सिर्फ़ एक बार"))
        val cmds = "pkg install android-tools\nadb pair IP:PAIR_PORT\nadb connect IP:PORT && adb tcpip 5555\nsleep 2; adb connect IP:5555"
        c3.addView(label(cmds, 13f, pal.text).apply {
            typeface = Typeface.MONOSPACE
            background = shape(pal.btn, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setTextIsSelectable(true)
        })
        c3.addView(row(pill("Commands कॉपी", h = 44) { copy(cmds) }, pill("पूरी Guide", h = 44) { show("settings") }))
        p.addView(c3)
        return p
    }

    private fun pageRemote(): LinearLayout {
        val p = col()
        val c1 = card()
        c1.addView(row(
            keyPill("⏻", 26, Color.parseColor("#E53935"), Color.WHITE),
            keyPill("Input", 178), keyPill("Menu", 82), keyPill("⚙ TV", 176)
        ))
        c1.addView(row(
            appPill("YouTube", "youtube", "#E62117"), appPill("Netflix", "netflix", "#B20710"),
            appPill("Prime", "prime", "#0F79AF"), appPill("Hotstar", "hotstar", "#1F3A8A")
        ))
        c1.addView(row(
            appPill("Chrome", "chrome", "#4285F4"), appPill("Browser", "browser", "#546E7A"),
            appPill("Settings", "settings", "#455A64")
        ))
        p.addView(c1)

        val c2 = card()
        val size = dp(250)
        val padv = FrameLayout(this).apply {
            background = oval(pal.btn)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(4); bottomMargin = dp(8)
            }
        }
        fun arrow(txt: String, code: Int, g: Int) {
            val t = TextView(this).apply {
                text = txt; textSize = 28f; gravity = Gravity.CENTER; setTextColor(pal.btnText)
                background = StateListDrawable().apply {
                    addState(intArrayOf(android.R.attr.state_pressed), oval(mix(pal.btn, pal.accent, 0.75f)))
                    addState(intArrayOf(), oval(Color.TRANSPARENT))
                }
                setOnTouchListener(holdListener(code))
            }
            padv.addView(t, FrameLayout.LayoutParams(dp(80), dp(80), g))
        }
        arrow("▲", 19, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        arrow("▼", 20, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        arrow("◀", 21, Gravity.START or Gravity.CENTER_VERTICAL)
        arrow("▶", 22, Gravity.END or Gravity.CENTER_VERTICAL)
        val ok = TextView(this).apply {
            text = "OK"; textSize = 20f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            setTextColor(onAccent); background = ovalPress(pal.accent)
            setOnClickListener { buzz(it); key(66) }
            pressFx()
        }
        padv.addView(ok, FrameLayout.LayoutParams(dp(92), dp(92), Gravity.CENTER))
        c2.addView(padv)
        c2.addView(row(keyPill("⬅ Back", 4), keyPill("🏠 Home", 3), keyPill("≡ Menu", 82)))
        p.addView(c2)

        val c3 = card()
        val vol = colOf(
            keyPill("＋", 24, hold = true, size = 22f), keyPill("🔇", 164), keyPill("－", 25, hold = true, size = 22f)
        )
        val chn = colOf(
            keyPill("＋", 166, hold = true, size = 22f), keyPill("CH", 0, pal.card, pal.sub).apply { setOnClickListener(null) },
            keyPill("－", 167, hold = true, size = 22f)
        )
        val vl = col().apply { addView(label("🔊 VOLUME", 12f, pal.sub, true).apply { gravity = Gravity.CENTER }); addView(vol) }
        val cl = col().apply { addView(label("📺 CHANNEL", 12f, pal.sub, true).apply { gravity = Gravity.CENTER }); addView(chn) }
        vl.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        cl.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        c3.addView(row(vl, cl))
        p.addView(c3)

        val c4 = card()
        c4.addView(row(keyPill("⏪", 89), keyPill("⏯", 85, pal.accent, onAccent), keyPill("⏹", 86), keyPill("⏩", 90)))
        c4.addView(row(
            keyPill("R", 183, Color.parseColor("#C62828"), Color.WHITE, h = 40),
            keyPill("G", 184, Color.parseColor("#2E7D32"), Color.WHITE, h = 40),
            keyPill("Y", 185, Color.parseColor("#F9A825"), Color.BLACK, h = 40),
            keyPill("B", 186, Color.parseColor("#1565C0"), Color.WHITE, h = 40)
        ))
        p.addView(c4)

        val c5 = card()
        val nums = col().apply { visibility = View.GONE }
        nums.addView(row(keyPill("1", 8), keyPill("2", 9), keyPill("3", 10)))
        nums.addView(row(keyPill("4", 11), keyPill("5", 12), keyPill("6", 13)))
        nums.addView(row(keyPill("7", 14), keyPill("8", 15), keyPill("9", 16)))
        nums.addView(row(keyPill("⌫", 67), keyPill("0", 7), keyPill("↵", 66)))
        val hdr = pill("🔢 नंबर पैड दिखाओ / छुपाओ", h = 44) { nums.visibility = if (nums.visibility == View.GONE) View.VISIBLE else View.GONE }
        c5.addView(row(hdr))
        c5.addView(nums)
        p.addView(c5)

        val c6 = card()
        c6.addView(title("TV पर टाइप करो / लिंक खोलो"))
        inputBox = edit("text या URL")
        c6.addView(inputBox)
        c6.addView(row(pill("Type", pal.accent, onAccent, 44) { typeText() }, pill("Open URL", h = 44) { openUrl() }, keyPill("Enter", 66, h = 44)))
        p.addView(c6)
        return p
    }

    private fun pagePad(): LinearLayout {
        val p = col()
        val seg = card()
        padMouse = col(); padKeys = col()
        seg.addView(row(
            pill("🖱 Mouse", pal.accent, onAccent, 44) { padMouse.visibility = View.VISIBLE; padKeys.visibility = View.GONE },
            pill("⌨ Keyboard", h = 44) { padMouse.visibility = View.GONE; padKeys.visibility = View.VISIBLE }
        ))
        p.addView(seg)

        touch = TextView(this).apply {
            text = "यहाँ उंगली चलाओ\nTap = क्लिक  •  Drag = स्वाइप"
            gravity = Gravity.CENTER; textSize = 16f; setTextColor(pal.sub)
            background = shape(pal.card, 20)
            layoutParams = LinearLayout.LayoutParams(-1, dp(300)).apply { bottomMargin = dp(10) }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { mx0 = e.x; my0 = e.y; mx1 = e.x; my1 = e.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        if (kotlin.math.abs(e.x - mx0) + kotlin.math.abs(e.y - my0) > 18) moved = true
                        mx1 = e.x; my1 = e.y
                    }
                    MotionEvent.ACTION_UP -> {
                        val w = v.width.coerceAtLeast(1).toFloat()
                        val h = v.height.coerceAtLeast(1).toFloat()
                        val x1 = (mx0 / w * tvW).toInt().coerceIn(0, tvW - 1)
                        val y1 = (my0 / h * tvH).toInt().coerceIn(0, tvH - 1)
                        val x2 = (mx1 / w * tvW).toInt().coerceIn(0, tvW - 1)
                        val y2 = (my1 / h * tvH).toInt().coerceIn(0, tvH - 1)
                        if (moved) sh("input swipe $x1 $y1 $x2 $y2 350") else sh("input tap $x1 $y1")
                    }
                }
                true
            }
        }
        padMouse.addView(touch)
        val m1 = card()
        m1.addView(row(keyPill("⬅ Back", 4), keyPill("🏠 Home", 3), keyPill("OK", 66, pal.accent, onAccent)))
        m1.addView(row(
            pill("⬆ Scroll") { sh("input swipe ${tvW / 2} ${tvH * 7 / 10} ${tvW / 2} ${tvH * 3 / 10} 300") },
            pill("⬇ Scroll") { sh("input swipe ${tvW / 2} ${tvH * 3 / 10} ${tvW / 2} ${tvH * 7 / 10} 300") }
        ))
        m1.addView(row(keyPill("◀", 21, hold = true), keyPill("▲", 19, hold = true), keyPill("▼", 20, hold = true), keyPill("▶", 22, hold = true)))
        padMouse.addView(m1)
        p.addView(padMouse)

        val k1 = card()
        k1.addView(title("मोबाइल कीबोर्ड से TV पर लिखो"))
        kbInput = edit("यहाँ टाइप करो")
        k1.addView(kbInput)
        k1.addView(row(pill("Send", pal.accent, onAccent, 46) { sendKeyboardText() }, keyPill("Enter", 66, h = 46), keyPill("⌫", 67, h = 46)))
        k1.addView(row(keyPill("Space", 62, h = 46), keyPill("Tab", 61, h = 46), keyPill("Esc", 111, h = 46)))
        k1.addView(row(keyPill("←", 21, hold = true, h = 46), keyPill("↑", 19, hold = true, h = 46), keyPill("↓", 20, hold = true, h = 46), keyPill("→", 22, hold = true, h = 46)))
        padKeys.addView(k1)
        padKeys.visibility = View.GONE
        p.addView(padKeys)
        return p
    }

    private fun pageApps(): LinearLayout {
        val p = col()
        val c = card()
        search = edit("🔍 ऐप खोजो")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { renderApps() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        c.addView(search)
        c.addView(row(pill("🔄 Refresh", h = 44) { loadApps() }))
        p.addView(c)
        appList = col()
        p.addView(appList)
        return p
    }

    private fun pageRam(): LinearLayout {
        val p = col()
        val c1 = card()
        c1.addView(title("TV RAM (लाइव)"))
        ramBig = label("--", 26f, pal.text, true)
        ramSub = label("जुड़ने के बाद दिखेगा", 13f, pal.sub)
        ramChart = LineChartView(this).apply {
            lineColor = pal.accent
            layoutParams = LinearLayout.LayoutParams(-1, dp(140)).apply { topMargin = dp(8) }
        }
        c1.addView(ramBig); c1.addView(ramSub); c1.addView(ramChart)
        p.addView(c1)

        val c2 = card()
        c2.addView(title("TV Storage"))
        storTv = label("--", 14f, pal.text)
        storBar = BarView(this).apply {
            fillColor = pal.accent
            layoutParams = LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(6) }
        }
        c2.addView(storTv); c2.addView(storBar)
        p.addView(c2)

        val c3 = card()
        c3.addView(title("कौन-सा ऐप कितनी RAM ले रहा है"))
        ramApps = col()
        c3.addView(ramApps)
        p.addView(c3)

        val c4 = card()
        c4.addView(title("📱 मेरा फ़ोन"))
        phoneRam = label("--", 14f, pal.text)
        phoneRamBar = BarView(this).apply {
            fillColor = pal.accent
            layoutParams = LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(6); bottomMargin = dp(10) }
        }
        phoneStor = label("--", 14f, pal.text)
        phoneStorBar = BarView(this).apply {
            fillColor = pal.accent
            layoutParams = LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(6) }
        }
        c4.addView(phoneRam); c4.addView(phoneRamBar); c4.addView(phoneStor); c4.addView(phoneStorBar)
        p.addView(c4)
        return p
    }

    private fun pageClose(): LinearLayout {
        val p = col()
        val c1 = card()
        c1.addView(title("तुरंत सफ़ाई"))
        c1.addView(row(
            pill("Background ऐप बंद", h = 46, size = 13f) { sh("am kill-all"); say("Background ऐप बंद किए") },
            pill("Cache साफ़", h = 46, size = 13f) { sh("pm trim-caches 1024G"); say("Cache साफ़ करने की कोशिश की") }
        ))
        c1.addView(row(
            pill("सारे 3rd-party ऐप बंद", Color.parseColor("#C62828"), Color.WHITE, 46, 13f) {
                sh("for p in $(pm list packages -3 | cut -d: -f2); do am force-stop \$p; done")
                say("सारे 3rd-party ऐप बंद किए")
            }
        ))
        p.addView(c1)
        val c2 = card()
        c2.addView(title("चल रहे ऐप (RAM के हिसाब से)"))
        c2.addView(row(pill("🔄 Refresh", h = 42) { refreshTop() }))
        closeList = col()
        c2.addView(closeList)
        p.addView(c2)
        return p
    }

    private fun pageTerm(): LinearLayout {
        val p = col().apply {
            setBackgroundColor(Color.parseColor("#0A0D12"))
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        termOut = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12.5f; setTextColor(Color.parseColor("#D6E2F0"))
            setPadding(dp(4), dp(4), dp(4), dp(4)); setTextIsSelectable(true)
        }
        termScroll = ScrollView(this).apply { isFillViewport = true; addView(termOut) }
        p.addView(termScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val defs = listOf(
            Triple("adb connect", "adb connect ", false), Triple("devices", "adb devices", true),
            Triple("adb shell", "adb shell", true), Triple("logcat", "adb logcat -t 200", true),
            Triple("wget", "wget ", false), Triple("ls", "ls -la", true),
            Triple("help", "help", true), Triple("clear", "clear", true)
        )
        for ((lb, cmd, run) in defs) {
            chips.addView(mini(lb) {
                termIn.setText(cmd); termIn.setSelection(cmd.length)
                if (run) termEnter() else termIn.requestFocus()
            })
        }
        p.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })

        val keysRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        keysRow.addView(mini("⌃C", Color.parseColor("#C62828"), Color.WHITE) { termInterrupt() })
        keysRow.addView(mini("↑") { termHistory(true) })
        keysRow.addView(mini("↓") { termHistory(false) })
        keysRow.addView(mini("Tab") { termTab() })
        for (s in listOf("/", "-", "|", "~", ">", "&", ".", ":", "\"")) keysRow.addView(mini(s) { termInsert(s) })
        keysRow.addView(mini("Paste") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            if (t.isNotEmpty()) termInsert(t)
        })
        p.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(keysRow) })

        termPrompt = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 13f; setTextColor(C_PROMPT)
            setPadding(dp(4), 0, dp(4), 0)
        }
        termIn = EditText(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(C_DIM)
            hint = "कमांड लिखो…  (help)"
            background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            setOnEditorActionListener { _, id, ev ->
                if (id == EditorInfo.IME_ACTION_SEND ||
                    (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)
                ) { termEnter(); true } else false
            }
        }
        val inRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#121821"))
        }
        inRow.addView(termPrompt)
        inRow.addView(termIn, LinearLayout.LayoutParams(0, -2, 1f))
        inRow.addView(mini("⏎ Run", pal.accent, onAccent) { termEnter() })
        p.addView(inRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        refreshPrompt()
        return p
    }

    private fun pageTools(): LinearLayout {
        val p = col()
        val c0 = card()
        c0.addView(title("⌨ Terminal"))
        c0.addView(label("Termux जैसा terminal अब अलग टैब में है: नीचे 'Term' टैब खोलो (adb, wget, असली sh)।", 13f, pal.sub))
        c0.addView(row(pill("⌨ Terminal खोलो", pal.accent, onAccent, 46, 14f) { show("term") }))
        p.addView(c0)

        val c2 = card()
        c2.addView(title("फ़ाइल टूल्स (फ़ोन ➜ TV)"))
        c2.addView(row(
            pill("📦 APK चुनो ➜ TV में install", h = 46, size = 13f) { pick(8) },
            pill("📁 File चुनो ➜ TV भेजो", h = 46, size = 13f) { pick(9) }
        ))
        val urlBox = edit("डाउनलोड लिंक (http/https)")
        c2.addView(urlBox)
        c2.addView(row(pill("⬇ फ़ोन में डाउनलोड ➜ TV /sdcard/Download", h = 46, size = 13f) {
            val u = urlBox.text.toString().trim()
            if (u.isNotEmpty()) downloadToTv(u)
        }))
        p.addView(c2)
        return p
    }

    private fun pageSettings(): LinearLayout {
        val p = col()
        val c1 = card()
        c1.addView(title("🎨 थीम / रंग"))
        val sw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (pl in PALETTES) {
            val item = col().apply {
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { buzz(it); pal = pl; prefs.edit().putString("theme", pl.name).apply(); buildUi() }
            }
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(pl.accent)
                    setStroke(dp(if (pl.name == pal.name) 4 else 1), if (pl.name == pal.name) pal.text else pal.sub)
                }
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            }
            item.addView(dot)
            item.addView(label(pl.name, 11f, pal.sub).apply { gravity = Gravity.CENTER })
            sw.addView(item)
        }
        c1.addView(sw)
        p.addView(c1)

        val c2 = card()
        c2.addView(title("⚙ विकल्प"))
        c2.addView(toggle("ऐप खुलते ही TV से auto-connect", "auto", true))
        c2.addView(toggle("बटन दबाने पर vibration", "haptic", true))
        c2.addView(toggle("ऐप चलते समय स्क्रीन ON रखो", "awake", true) { on ->
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        })
        p.addView(c2)

        p.addView(title("📖 मैनुअल (टैप करके खोलो)"))
        p.addView(manual("1️⃣  TV में ADB चालू करो",
            "• TV: Settings → Device Preferences → About → 'Build' पर 7 बार OK दबाओ (Developer mode ON)।\n" +
            "• पीछे जाकर Developer options खोलो → 'USB debugging' ON करो। अगर 'ADB debugging' / 'Network debugging' / 'Wireless debugging' दिखे तो वह भी ON करो।\n" +
            "• फ़ोन और TV एक ही WiFi पर हों (या TV फ़ोन के हॉटस्पॉट पर हो)।\n" +
            "• TV का IP: Settings → Network → अपना WiFi → IP address।"))
        p.addView(manual("2️⃣  ऐप से जोड़ना",
            "• Connect टैब खोलो, IP:Port डालो (जैसे 192.168.1.20:5555) और Connect दबाओ। या सिर्फ़ Scan दबाओ, TV खुद मिल जाएगा।\n" +
            "• पहली बार TV स्क्रीन पर 'Allow USB debugging?' आएगा → 'Always allow' टिक करके OK दबाओ।\n" +
            "• ऊपर '● जुड़ा हुआ' दिखे तो Remote टैब इस्तेमाल करो।"))
        p.addView(manual("3️⃣  Termux वाला तरीका (Android 11+ TV)",
            "नए TV में सिर्फ़ 'Wireless debugging' होती है और पोर्ट 5555 बंद रहता है। तब एक बार Termux से पोर्ट खोलो:\n\n" +
            "① Termux में: pkg install android-tools\n" +
            "② TV: Developer options → Wireless debugging ON → 'Pair device with pairing code' दबाओ (IP:PORT और कोड दिखेगा)\n" +
            "③ Termux में: adb pair IP:PAIR_PORT  (फिर कोड डालो)\n" +
            "④ Termux में: adb connect IP:PORT  (Wireless debugging वाली मुख्य स्क्रीन का पोर्ट)\n" +
            "⑤ Termux में: adb tcpip 5555\n" +
            "⑥ अब इस ऐप में IP:5555 डालकर Connect करो और TV पर Allow दबाओ।\n\n" +
            "TV रीस्टार्ट होने पर ⑤ दोबारा करना पड़ सकता है।"))
        p.addView(manual("4️⃣  दिक्कतें और हल",
            "• नहीं जुड़ा / timeout: IP ग़लत, अलग WiFi, या TV में ADB बंद है। पहले 🔧 Fix Connection दबाओ (ऐप खुद 4 बार कोशिश करता है)।\n" +
            "• 'device offline': पुराना कनेक्शन अटका है। Termux में adb disconnect → adb kill-server → adb connect IP:5555 → adb devices चलाओ। पहली बार 'failed' आना आम है, दोबारा connect करने पर जुड़ जाता है।\n" +
            "• फिर भी offline: TV में USB debugging OFF→ON करो और ऐप में 🔑 Reset Key दबाकर दोबारा Connect करो।\n" +
            "• TV पर Allow वाला popup नहीं आया: TV में Developer options → 'Revoke USB debugging authorizations' करो, फिर दोबारा Connect।\n" +
            "• बार-बार कट जाता है: TV का IP बदल गया होगा, Scan दबाओ।\n" +
            "• Mouse सही जगह टच नहीं करता: कुछ TV टच इनपुट ब्लॉक करते हैं, तब D-pad इस्तेमाल करो।\n" +
            "• Power बटन TV को standby करता है; बंद TV में WiFi भी बंद हो जाता है, इसलिए ADB से वापस ON नहीं होगा।\n" +
            "• सारे 3rd-party ऐप बंद करने से बैकग्राउंड ऐप रुकते हैं, TV का सिस्टम सुरक्षित रहता है।"))
        p.addView(manual("5️⃣  टैब क्या करते हैं",
            "🔌 Connect: TV से जुड़ो / Scan / Termux commands\n" +
            "🎮 Remote: पूरा रिमोट, ऐप शॉर्टकट, टाइपिंग, URL\n" +
            "🖱 Pad: टचपैड माउस + कीबोर्ड\n" +
            "📱 Apps: TV के ऐप खोलो और बंद करो\n" +
            "📊 RAM: लाइव RAM ग्राफ़, Storage, ऐप-वार RAM, मेरे फ़ोन की RAM/Storage\n" +
            "🧹 Close: बैकग्राउंड ऐप और cache साफ़, ऐप बंद करो\n" +
            "⌨ Term: Termux जैसा terminal (adb, wget/curl, फ़ोन का sh)\n" +
            "💻 Tools: APK install, फ़ाइल भेजो, डाउनलोड\n" +
            "🎤 ऊपर: हिंदी/इंग्लिश वॉइस कमांड (जैसे 'वॉल्यूम बढ़ा', 'यूट्यूब')"))
        p.addView(label("Smart TV Remote v2.1", 12f, pal.sub).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) })
        return p
    }

    private fun toggle(text: String, key: String, def: Boolean, f: ((Boolean) -> Unit)? = null): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        r.addView(label(text, 14f, pal.text), LinearLayout.LayoutParams(0, -2, 1f))
        val b = TextView(this).apply {
            textSize = 13f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(36)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        }
        fun paint() {
            val on = prefs.getBoolean(key, def)
            b.text = if (on) "ON" else "OFF"
            b.setTextColor(if (on) onAccent else pal.btnText)
            b.background = ripple(if (on) pal.accent else pal.btn, 18)
        }
        paint()
        b.pressFx()
        b.setOnClickListener {
            buzz(it)
            val now = !prefs.getBoolean(key, def)
            prefs.edit().putBoolean(key, now).apply()
            paint()
            f?.invoke(now)
        }
        r.addView(b)
        return r
    }

    private fun manual(head: String, body: String): View {
        val c = card()
        val b = label(body, 14f, pal.sub).apply {
            visibility = View.GONE; setPadding(0, dp(10), 0, 0); setLineSpacing(0f, 1.2f)
        }
        val h = label("$head   ▾", 16f, pal.text, true)
        c.setOnClickListener { b.visibility = if (b.visibility == View.GONE) View.VISIBLE else View.GONE }
        c.addView(h); c.addView(b)
        return c
    }

    // ================= Status =================
    private fun say(s: String) {
        ui.post {
            if (::topStatus.isInitialized) {
                topStatus.text = (if (connected) "● " else "○ ") + s
                topStatus.setTextColor(if (connected) Color.parseColor("#4CAF50") else pal.sub)
            }
            refreshConnectCard()
        }
    }

    private fun refreshConnectCard() {
        if (!::connStatus.isInitialized || !::connInfo.isInitialized) return
        if (connected) {
            connStatus.text = "🟢 जुड़ा हुआ"
            connInfo.text = "${prefs.getString("ip", "")}  •  $tvName  •  ${tvW}x$tvH"
        } else {
            connStatus.text = "🔴 जुड़ा नहीं"
            connInfo.text = if (lastError.isNotEmpty()) lastError else "नीचे IP डालकर Connect दबाओ, या Scan करो"
        }
    }

    // ================= ADB =================
    private fun keys(): AdbKeyPair {
        val pr = File(filesDir, "adbkey")
        val pu = File(filesDir, "adbkey.pub")
        if (!pr.exists() || !pu.exists()) AdbKeyPair.generate(pr, pu)
        return AdbKeyPair.read(pr, pu)
    }

    private fun cleanTarget(raw: String): String =
        raw.trim().removePrefix("adb connect").trim().replace(" ", "")

    private fun tcpProbe(host: String, port: Int): String = try {
        Socket().use { it.connect(InetSocketAddress(host, port), 4000) }
        "OK"
    } catch (e: Exception) {
        val m = e.message ?: e.javaClass.simpleName
        when {
            e is java.net.SocketTimeoutException -> "TIMEOUT"
            m.contains("ECONNREFUSED", true) || m.contains("refused", true) -> "REFUSED"
            else -> "ERR:$m"
        }
    }

    private fun phoneIps(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.interfaceAddresses }
            .mapNotNull { (it.address as? Inet4Address)?.takeIf { a -> !a.isLoopbackAddress }?.hostAddress }
    } catch (_: Exception) { emptyList() }

    private fun connect(raw: String): Boolean {
        try { dadb?.close() } catch (_: Exception) {}
        dadb = null
        connected = false
        fatal = false
        val ip = cleanTarget(raw)
        val host = ip.substringBeforeLast(':', ip)
        val port = ip.substringAfterLast(':', "5555").toIntOrNull() ?: 5555
        say("जोड़ रहा हूँ $host:$port ...")
        // 1) पहले देखो कि TV का port खुला भी है या नहीं
        val probe = tcpProbe(host, port)
        if (probe != "OK") {
            fatal = true
            lastError = when (probe) {
                "REFUSED" -> "TV मिला, पर port $port बंद है — TV में ADB (TCP) चालू नहीं। Termux में एक बार: adb connect IP:WIRELESS_PORT && adb tcpip 5555, फिर यहाँ IP:5555 डालो।"
                "TIMEOUT" -> "TV से जवाब नहीं ($host)। IP ग़लत / TV standby / फ़ोन और TV अलग WiFi / router में AP-isolation। 🩺 Diagnose दबाओ।"
                else -> "नेटवर्क error: " + probe.removePrefix("ERR:")
            }
            say(lastError)
            return false
        }
        // 2) ADB handshake (timeout के साथ, ताकि Allow popup पर हमेशा के लिए अटके नहीं)
        val fut = bg.submit(Callable<Dadb> {
            val x = Dadb.create(host, port, keys())
            x.shell("echo ok")
            x
        })
        val d: Dadb = try {
            fut.get(40, TimeUnit.SECONDS)
        } catch (e: TimeoutException) {
            fut.cancel(true)
            fatal = true
            lastError = "40 सेकंड में जवाब नहीं — TV स्क्रीन पर 'Allow USB debugging?' आया होगा: 'Always allow' टिक करके OK दबाओ, फिर Connect दबाओ।"
            say(lastError)
            return false
        } catch (e: Exception) {
            val c = e.cause ?: e
            val m = c.message ?: c.javaClass.simpleName
            lastError = "जुड़ नहीं पाया ($m)। " +
                (if (port != 5555) "Port $port शायद Wireless-debugging (TLS) वाला है, यह ऐप उससे नहीं जुड़ता — Termux से adb tcpip 5555 करके IP:5555 आज़माओ। " else "") +
                "TV में USB debugging OFF→ON करो, 🔑 Reset Key दबाओ, फिर Connect।"
            say(lastError)
            return false
        }
        dadb = d
        connected = true
        lastError = ""
        try {
            val wm = d.shell("wm size").output
            Regex("(\\d+)x(\\d+)").findAll(wm).lastOrNull()?.let {
                tvW = it.groupValues[1].toInt(); tvH = it.groupValues[2].toInt()
            }
        } catch (_: Exception) {}
        try { tvName = d.shell("getprop ro.product.model").output.trim() } catch (_: Exception) {}
        say("जुड़ गया: $host:$port")
        loadApps(false)
        return true
    }

    private fun connectRetry(ip: String, tries: Int = 3): Boolean {
        for (i in 1..tries) {
            if (connect(ip)) return true
            if (fatal) return false
            if (i < tries) {
                say("दोबारा कोशिश ($i/$tries)...")
                try { Thread.sleep(1500) } catch (_: Exception) {}
            }
        }
        return false
    }

    private fun diagnose() {
        val typed = cleanTarget(ipBox.text.toString()).ifEmpty { prefs.getString("ip", "") ?: "" }
        if (typed.isEmpty()) { say("पहले TV का IP डालो"); return }
        val host = typed.substringBeforeLast(':', typed)
        val port = typed.substringAfterLast(':', "5555").toIntOrNull() ?: 5555
        diagOut.text = "जाँच चल रही है..."
        io.execute {
            val sb = StringBuilder()
            val mine = phoneIps()
            sb.append("📱 फ़ोन IP: ").append(mine.joinToString().ifEmpty { "कोई WiFi नहीं!" }).append("\n")
            val same = mine.any { it.substringBeforeLast('.') == host.substringBeforeLast('.') }
            sb.append(if (same) "✅ फ़ोन और TV एक ही नेटवर्क पर हैं\n" else "❌ फ़ोन और TV अलग नेटवर्क पर लगते हैं (IP का शुरू वाला हिस्सा अलग)\n")
            var open5555 = false
            for (p in listOf(port, 5555).distinct()) {
                val r = tcpProbe(host, p)
                if (p == 5555 && r == "OK") open5555 = true
                sb.append(when (r) {
                    "OK" -> "✅ port $p खुला है\n"
                    "REFUSED" -> "❌ port $p बंद है (वहाँ ADB चालू नहीं)\n"
                    "TIMEOUT" -> "❌ port $p: जवाब नहीं (IP ग़लत / TV बंद / अलग WiFi)\n"
                    else -> "❌ port $p: ${r.removePrefix("ERR:")}\n"
                })
            }
            sb.append("\n")
            sb.append(
                when {
                    !same && mine.isNotEmpty() -> "👉 फ़ोन और TV को एक ही WiFi पर लाओ।"
                    open5555 -> "👉 सब ठीक है। Connect दबाओ; TV पर 'Allow USB debugging?' आए तो Always allow।"
                    else -> "👉 Port 5555 बंद है। अगर Termux किसी और port (Wireless debugging) से जुड़ा था, तो यह ऐप उस TLS port से नहीं जुड़ सकता। Termux में चलाओ:\n  adb connect IP:PORT\n  adb tcpip 5555\nफिर यहाँ IP:5555 डालकर Connect करो।"
                }
            )
            ui.post { diagOut.text = sb.toString() }
        }
    }

    private fun fixConnection() {
        val typed = ipBox.text.toString().trim()
        val ip = if (typed.isNotEmpty()) typed else (prefs.getString("ip", "") ?: "")
        if (ip.isEmpty()) { say("पहले IP डालो"); return }
        prefs.edit().putString("ip", ip).apply()
        say("Fix: पुराना कनेक्शन बंद करके दोबारा जोड़ रहा हूँ...")
        io.execute {
            try { dadb?.close() } catch (_: Exception) {}
            dadb = null
            connected = false
            try { Thread.sleep(1500) } catch (_: Exception) {}
            if (!connectRetry(ip, 4)) {
                say("नहीं जुड़ा। TV में USB debugging OFF→ON करो, फिर 🔑 Reset Key दबाओ")
            }
        }
    }

    private fun resetKey() {
        io.execute {
            try { dadb?.close() } catch (_: Exception) {}
            dadb = null
            connected = false
            File(filesDir, "adbkey").delete()
            File(filesDir, "adbkey.pub").delete()
            say("नई Key बन गई। अब Connect दबाओ और TV पर Allow करो")
        }
    }

    private fun connectClicked() {
        val ip = cleanTarget(ipBox.text.toString())
        if (ip.isEmpty()) { say("पहले IP डालो या Scan दबाओ"); return }
        prefs.edit().putString("ip", ip).apply()
        io.execute { connectRetry(ip) }
    }

    private fun disconnect() {
        io.execute {
            try { dadb?.close() } catch (_: Exception) {}
            dadb = null
            connected = false
            say("कनेक्शन बंद किया")
        }
    }

    private fun sh(cmd: String, cb: ((String) -> Unit)? = null) = io.execute {
        fun exec(): String { val r = dadb!!.shell(cmd); return r.output + r.errorOutput }
        var out: String? = null
        try { out = exec() } catch (e: Exception) {
            val ip = prefs.getString("ip", "") ?: ""
            if (ip.isNotEmpty()) {
                if (connectRetry(ip, 2)) {
                    try { out = exec() } catch (_: Exception) { say("कमांड फेल") }
                }
            } else {
                say("पहले Connect टैब से TV जोड़ो")
            }
        }
        val o = out
        if (cb != null && o != null) ui.post { cb(o) }
    }

    private fun key(code: Int) = sh("input keyevent $code")
    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun typeText() {
        val t = inputBox.text.toString()
        if (t.isEmpty()) return
        sh("input text " + q(t.replace(" ", "%s")))
        inputBox.setText("")
    }

    private fun openUrl() {
        var u = inputBox.text.toString().trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http")) u = "http://$u"
        sh("am start -a android.intent.action.VIEW -d " + q(u))
    }

    private fun sendKeyboardText() {
        val value = kbInput.text.toString()
        if (value.isBlank()) return
        sh("input text " + q(value.replace(" ", "%s")))
        kbInput.setText("")
    }

    // ================= Terminal =================
    private val MARK = "@@TVR@@"
    private val ansi = Regex("\\u001B\\[[0-9;?]*[ -/]*[@-~]")
    private val C_PROMPT = Color.parseColor("#7CFC9A")
    private val C_TV = Color.parseColor("#FFC857")
    private val C_ERR = Color.parseColor("#FF6B6B")
    private val C_DIM = Color.parseColor("#8FA3B8")

    private val HELP = """
Smart TV Remote - Terminal
--------------------------
ADB (built-in):
  adb connect IP[:PORT]        TV से जुड़ो (default 5555)
  adb devices | disconnect | kill-server
  adb shell [cmd]              TV का शेल (exit से बाहर)
  adb install <file|url>       APK TV में install
  adb push <file|url> <path>   फ़ाइल TV में भेजो
  adb uninstall <pkg>   adb reboot   adb logcat [opts]
डाउनलोड (फ़ोन में):
  wget <url> [-O name]   curl -L <url> -o name   download <url>
फ़ोन का असली शेल: ls cd cat cp mv rm mkdir ping nc grep ...
Keys: up/down = history, Tab = complete, ^C = शेल रीस्टार्ट
और: clear, help, termux (Termux खोलो)
""".trimIndent()

    private val PAIR_MSG = """
यह ऐप का built-in adb सिर्फ़ classic TCP (port 5555) से जुड़ता है।
Android 11+ 'Wireless debugging' port (TLS) और 'adb pair' अभी built-in नहीं हैं।
एक बार Termux में ये चलाओ (TV का IP / PORT / CODE डालकर):
  adb pair IP:PAIRPORT
  adb connect IP:PORT && adb tcpip 5555
फिर यहाँ:  adb connect IP:5555
""".trimIndent()

    private fun clean(s: String) = ansi.replace(s, "").replace("\r", "")

    private fun termPut(s: String, color: Int? = null) {
        val st = termSpan.length
        termSpan.append(s)
        if (color != null) termSpan.setSpan(
            android.text.style.ForegroundColorSpan(color), st, termSpan.length,
            android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        if (termSpan.length > 40000) termSpan.delete(0, termSpan.length - 30000)
        if (::termOut.isInitialized) {
            termOut.text = termSpan
            termScroll.post { termScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun termLine(s: String, color: Int? = null) {
        if (termSpan.isNotEmpty() && termSpan[termSpan.length - 1] != '\n') termPut("\n")
        termPut(s + "\n", color)
    }

    private fun termLn(s: String, color: Int? = null) { ui.post { termLine(s, color) } }

    private fun shortCwd(): String {
        val home = File(filesDir, "home").path
        return when {
            cwd == home -> "~"
            cwd.startsWith("$home/") -> "~" + cwd.removePrefix(home)
            cwd.isEmpty() -> "~"
            else -> cwd
        }
    }

    private fun promptText(): String =
        (if (inTv) "${tvName.ifEmpty { "tv" }}:$tvCwd" else shortCwd()) + " $"

    private fun refreshPrompt() {
        if (!::termPrompt.isInitialized) return
        termPrompt.text = (if (busy) "… " else "") + promptText()
        termPrompt.setTextColor(if (inTv) C_TV else C_PROMPT)
    }

    private fun tokenize(s: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var quote = '\u0000'
        var has = false
        for (ch in s) {
            when {
                quote != '\u0000' -> if (ch == quote) quote = '\u0000' else cur.append(ch)
                ch == '"' || ch == '\'' -> { quote = ch; has = true }
                ch.isWhitespace() -> if (cur.isNotEmpty() || has) { out.add(cur.toString()); cur.setLength(0); has = false }
                else -> cur.append(ch)
            }
        }
        if (cur.isNotEmpty() || has) out.add(cur.toString())
        return out
    }

    private fun sz(b: Long): String = when {
        b >= (1L shl 30) -> String.format("%.2f GB", b / 1073741824.0)
        b >= (1L shl 20) -> String.format("%.1f MB", b / 1048576.0)
        b >= 1024 -> "${b / 1024} KB"
        else -> "$b B"
    }

    // ---- phone shell (persistent /system/bin/sh) ----
    private fun ensureLocal() {
        if (localProc?.isAlive == true) return
        val home = File(filesDir, "home").apply { mkdirs() }
        try {
            val dir = if (cwd.isNotEmpty() && File(cwd).isDirectory) File(cwd) else home
            val pb = ProcessBuilder("/system/bin/sh").directory(dir).redirectErrorStream(true)
            pb.environment().apply {
                put("HOME", home.path)
                put("TMPDIR", cacheDir.path)
                put("TERM", "dumb")
                put("PATH", File(filesDir, "bin").path + ":/system/bin:/system/xbin:/vendor/bin")
            }
            val p = pb.start()
            localProc = p
            localIn = p.outputStream
            cwd = dir.path
            Thread {
                val rd = java.io.InputStreamReader(p.inputStream, Charsets.UTF_8)
                val buf = CharArray(4096)
                val acc = StringBuilder()
                try {
                    while (true) {
                        val n = rd.read(buf)
                        if (n < 0) break
                        acc.append(buf, 0, n)
                        pumpLocal(acc)
                    }
                } catch (_: Exception) {}
                ui.post {
                    if (localProc === p) {
                        termLine("[शेल बंद हो गया — अगली कमांड पर दोबारा शुरू होगा]", C_ERR)
                        busy = false; refreshPrompt()
                    }
                }
            }.start()
        } catch (e: Exception) {
            termLine("शेल शुरू नहीं हुआ: ${e.message}", C_ERR)
        }
    }

    private fun pumpLocal(acc: StringBuilder) {
        while (true) {
            val i = acc.indexOf(MARK)
            if (i >= 0) {
                val nl = acc.indexOf("\n", i)
                if (nl < 0) {
                    if (i > 0) { val t = acc.substring(0, i); acc.delete(0, i); ui.post { termPut(clean(t)) } }
                    return
                }
                val before = acc.substring(0, i)
                val meta = acc.substring(i + MARK.length, nl)
                acc.delete(0, nl + 1)
                ui.post {
                    if (before.isNotEmpty()) termPut(clean(before))
                    val k = meta.indexOf(':')
                    if (k > 0) cwd = meta.substring(k + 1).trim()
                    busy = false
                    refreshPrompt()
                }
            } else {
                var keep = 0
                for (k in (MARK.length - 1) downTo 1) {
                    if (acc.endsWith(MARK.substring(0, k))) { keep = k; break }
                }
                val n = acc.length - keep
                if (n > 0) { val t = acc.substring(0, n); acc.delete(0, n); ui.post { termPut(clean(t)) } }
                return
            }
        }
    }

    private fun writeLocal(text: String) {
        ensureLocal()
        val o = localIn ?: return
        bg.execute {
            try { o.write(text.toByteArray()); o.flush() } catch (e: Exception) {
                ui.post { termLine("शेल में लिख नहीं पाया: ${e.message}", C_ERR); busy = false; refreshPrompt() }
            }
        }
    }

    private fun sendLocal(cmd: String) {
        busy = true; refreshPrompt()
        writeLocal(cmd + "\necho \"" + MARK + "\$?:\$PWD\"\n")
    }

    private fun termInterrupt() {
        termLine("^C", C_ERR)
        termIn.setText("")
        busy = false
        if (!inTv) {
            try { localProc?.destroy() } catch (_: Exception) {}
            localProc = null; localIn = null
            ensureLocal()
        }
        refreshPrompt()
    }

    // ---- TV shell (adb shell over dadb) ----
    private fun runTv(cmd: String, track: Boolean) {
        if (dadb == null) { termLine("error: TV से जुड़े नहीं — पहले: adb connect IP:5555", C_ERR); return }
        busy = true; refreshPrompt()
        val startDir = if (track) tvCwd else "/"
        bg.execute {
            fun attempt(): Pair<String, String?> {
                val d = dadb ?: throw IllegalStateException("TV से जुड़े नहीं")
                val r = d.shell("cd " + q(startDir) + " 2>/dev/null\n" + cmd + "\necho \"" + MARK + "\$?:\$PWD\"")
                val all = r.output + r.errorOutput
                val i = all.lastIndexOf(MARK)
                return if (i >= 0) {
                    val meta = all.substring(i + MARK.length).trim()
                    Pair(all.substring(0, i), meta.substringAfter(':', "").ifEmpty { null })
                } else Pair(all, null)
            }
            val res: Pair<String, String?> = try { attempt() } catch (e: Exception) {
                val ip = prefs.getString("ip", "") ?: ""
                if (ip.isNotEmpty() && connectRetry(ip, 1)) {
                    try { attempt() } catch (e2: Exception) { Pair("error: ${e2.message ?: e2.javaClass.simpleName}\n", null) }
                } else Pair("error: ${e.message ?: e.javaClass.simpleName}\n", null)
            }
            ui.post {
                val o = clean(res.first)
                if (o.isNotEmpty()) { termPut(o); if (!o.endsWith("\n")) termPut("\n") }
                val nc = res.second
                if (track && nc != null) tvCwd = nc
                busy = false
                refreshPrompt()
            }
        }
    }

    // ---- downloads ----
    private fun isUrl(s: String) = s.startsWith("http://") || s.startsWith("https://")

    private fun openFollow(start: String): HttpURLConnection {
        var u = URL(if (start.contains("://")) start else "https://$start")
        var hops = 0
        while (true) {
            val c = u.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) TVRemote")
            val code = c.responseCode
            if (code in 300..399 && hops < 8) {
                val loc = c.getHeaderField("Location") ?: throw java.io.IOException("redirect में Location नहीं")
                u = URL(u, loc)
                c.disconnect()
                hops++
                continue
            }
            if (code !in 200..299) { c.disconnect(); throw java.io.IOException("HTTP $code") }
            return c
        }
    }

    private fun downloadFile(url: String, target: String?, baseDir: File): File {
        val c = openFollow(url)
        val nm = (target ?: c.url.path.substringAfterLast('/')).ifEmpty { "download.bin" }
        val f = if (nm.startsWith("/")) File(nm) else File(baseDir, nm.replace("/", "_"))
        val total = c.contentLengthLong
        var done = 0L
        var lastT = 0L
        c.inputStream.use { ins ->
            f.outputStream().use { o ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                    done += n
                    val now = System.currentTimeMillis()
                    if (now - lastT > 800) {
                        lastT = now
                        termLn(if (total > 0) "  ${sz(done)} / ${sz(total)}  (${done * 100 / total}%)" else "  ${sz(done)}", C_DIM)
                    }
                }
            }
        }
        c.disconnect()
        return f
    }

    private fun downloadCmd(tk: List<String>) {
        var url: String? = null
        var name: String? = null
        var i = 1
        while (i < tk.size) {
            val a = tk[i]
            when {
                a == "-o" || a == "--output" || a == "--output-document" -> { name = tk.getOrNull(i + 1); i++ }
                a == "-O" && tk[0] == "wget" -> { name = tk.getOrNull(i + 1); i++ }
                a.startsWith("-") -> {}
                url == null -> url = a
            }
            i++
        }
        val u = url
        if (u == null) { termLine("usage: wget <url> [-O name]", C_ERR); return }
        busy = true; refreshPrompt()
        val dir = if (cwd.isNotEmpty() && File(cwd).isDirectory) File(cwd) else File(filesDir, "home")
        bg.execute {
            try {
                termLn("⬇ $u", C_DIM)
                val f = downloadFile(u, name, dir)
                termLn("✔ सेव हुआ: ${f.path}  (${sz(f.length())})", C_PROMPT)
            } catch (e: Exception) {
                termLn("✖ डाउनलोड फेल: ${e.message ?: e.javaClass.simpleName}", C_ERR)
            }
            ui.post { busy = false; refreshPrompt() }
        }
    }

    private fun resolveSrc(src: String): File {
        if (isUrl(src)) {
            termLn("⬇ $src", C_DIM)
            return downloadFile(src, null, cacheDir)
        }
        val f = if (src.startsWith("/")) File(src) else File(cwd, src)
        if (!f.exists()) throw java.io.FileNotFoundException("${f.path}: No such file")
        return f
    }

    // ---- built-in adb ----
    private fun adbCmd(a: List<String>, line: String) {
        val sub = a.firstOrNull() ?: "help"
        val notConn = { termLine("error: no devices — पहले: adb connect IP:5555", C_ERR) }
        when (sub) {
            "help", "--help", "-h" -> termLine(HELP, C_DIM)
            "version" -> termLine("Android Debug Bridge (built-in dadb client)")
            "start-server" -> termLine("* built-in adb: server की ज़रूरत नहीं")
            "kill-server", "disconnect" -> {
                inTv = false; refreshPrompt()
                disconnect()
                termLine("disconnected")
            }
            "devices" -> termLine("List of devices attached\n" + (if (connected) "${prefs.getString("ip", "")}\tdevice" else "") + "\n")
            "get-state" -> termLine(if (connected) "device" else "offline")
            "connect" -> {
                val t = cleanTarget(a.getOrNull(1) ?: (prefs.getString("ip", "") ?: ""))
                if (t.isEmpty()) { termLine("usage: adb connect IP[:PORT]", C_ERR); return }
                val target = if (t.contains(':')) t else "$t:5555"
                busy = true; refreshPrompt()
                bg.execute {
                    val ok = connectRetry(target, 2)
                    ui.post {
                        if (ok) {
                            prefs.edit().putString("ip", target).apply()
                            if (::ipBox.isInitialized) ipBox.setText(target)
                            termLine("connected to $target", C_PROMPT)
                        } else termLine("failed to connect to $target\n$lastError", C_ERR)
                        busy = false; refreshPrompt()
                    }
                }
            }
            "shell" -> {
                if (dadb == null) { notConn(); return }
                val rest = line.trim().removePrefix("adb").trim().removePrefix("shell").trim()
                if (rest.isEmpty()) {
                    inTv = true; tvCwd = "/"; refreshPrompt()
                    termLine("TV शेल चालू — बाहर निकलने के लिए: exit", C_DIM)
                } else runTv(rest, false)
            }
            "install", "install-multiple" -> {
                val src = a.drop(1).firstOrNull { !it.startsWith("-") }
                if (src == null) { termLine("usage: adb install <file|url>", C_ERR); return }
                if (dadb == null) { notConn(); return }
                busy = true; refreshPrompt()
                bg.execute {
                    try {
                        val f = resolveSrc(src)
                        termLn("Performing Streamed Install (${sz(f.length())}) ...", C_DIM)
                        val d = dadb ?: throw IllegalStateException("TV से जुड़े नहीं")
                        d.install(f)
                        termLn("Success", C_PROMPT)
                        if (isUrl(src)) f.delete()
                    } catch (e: Exception) {
                        termLn("Failure: ${e.message ?: e.javaClass.simpleName}", C_ERR)
                    }
                    ui.post { busy = false; refreshPrompt() }
                }
            }
            "push" -> {
                val src = a.getOrNull(1)
                val dst = a.getOrNull(2)
                if (src == null || dst == null) { termLine("usage: adb push <file|url> <remote path>", C_ERR); return }
                if (dadb == null) { notConn(); return }
                busy = true; refreshPrompt()
                bg.execute {
                    try {
                        val f = resolveSrc(src)
                        val remote = if (dst.endsWith("/")) dst + f.name else dst
                        val d = dadb ?: throw IllegalStateException("TV से जुड़े नहीं")
                        d.push(f, remote)
                        termLn("${f.name}: pushed to $remote (${sz(f.length())})", C_PROMPT)
                        if (isUrl(src)) f.delete()
                    } catch (e: Exception) {
                        termLn("push failed: ${e.message ?: e.javaClass.simpleName}", C_ERR)
                    }
                    ui.post { busy = false; refreshPrompt() }
                }
            }
            "uninstall" -> {
                val pk = a.getOrNull(1)
                if (pk == null) termLine("usage: adb uninstall <package>", C_ERR) else runTv("pm uninstall " + q(pk), false)
            }
            "logcat" -> {
                val rest = a.drop(1).joinToString(" ").ifEmpty { "-t 300" }
                runTv("logcat -d -v time $rest", false)
            }
            "reboot" -> runTv("reboot " + a.drop(1).joinToString(" "), false)
            "pair", "tcpip", "usb", "mdns" -> termLine(PAIR_MSG, C_TV)
            else -> termLine("adb: unknown command '$sub'  (adb help देखो)", C_ERR)
        }
    }

    private fun openTermux() {
        val i = packageManager.getLaunchIntentForPackage("com.termux")
        if (i != null) startActivity(i) else termLine("Termux इंस्टॉल नहीं है", C_ERR)
    }

    private fun termSubmit(raw: String) {
        val line = raw.trim()
        termLine(promptText() + " " + line, if (inTv) C_TV else C_PROMPT)
        if (line.isEmpty()) return
        if (history.isEmpty() || history.last() != line) history.add(line)
        histPos = history.size
        val tk = tokenize(line)
        val head = tk.firstOrNull() ?: return
        when (head) {
            "clear", "cls" -> { termSpan.clear(); termOut.text = ""; return }
            "help", "?" -> { termLine(HELP, C_DIM); return }
            "wget", "curl", "download" -> { downloadCmd(tk); return }
            "adb" -> { adbCmd(tk.drop(1), line); return }
            "termux" -> { openTermux(); return }
            "pkg", "apt", "apt-get" -> {
                termLine("यह Termux का pkg नहीं है। यहाँ built-in: adb, wget/curl, और फ़ोन का sh। असली Termux के लिए: termux", C_TV)
                return
            }
            "exit", "logout" -> if (inTv) {
                inTv = false; refreshPrompt()
                termLine("TV शेल से बाहर", C_DIM)
                return
            }
        }
        if (inTv) runTv(line, true) else sendLocal(line)
    }

    private fun termEnter() {
        val t = termIn.text.toString()
        termIn.setText("")
        termSubmit(t)
    }

    private fun termHistory(up: Boolean) {
        if (history.isEmpty()) return
        if (up) {
            if (histPos > 0) histPos--
            termIn.setText(history[histPos])
        } else {
            if (histPos < history.size - 1) { histPos++; termIn.setText(history[histPos]) }
            else { histPos = history.size; termIn.setText("") }
        }
        termIn.setSelection(termIn.text.length)
    }

    private fun termTab() {
        if (inTv) return
        val t = termIn.text.toString()
        val cur = t.substringAfterLast(' ')
        val dirPart = if (cur.contains('/')) cur.substringBeforeLast('/') + "/" else ""
        val prefix = cur.substringAfterLast('/')
        val dir = if (dirPart.startsWith("/")) File(dirPart) else File(cwd, dirPart)
        val names = (dir.list() ?: return).filter { it.startsWith(prefix) }.sorted()
        if (names.isEmpty()) return
        val rep: String
        if (names.size == 1) {
            rep = dirPart + names[0] + (if (File(dir, names[0]).isDirectory) "/" else " ")
        } else {
            termLine(names.joinToString("  "), C_DIM)
            rep = dirPart + names.reduce { x, y -> x.commonPrefixWith(y) }
        }
        termIn.setText(t.dropLast(cur.length) + rep)
        termIn.setSelection(termIn.text.length)
    }

    private fun termInsert(s: String) {
        val pos = termIn.selectionStart.coerceAtLeast(0)
        termIn.text.insert(pos, s)
    }

    private fun pick(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        try { startActivityForResult(i, code) } catch (e: Exception) { toast("File picker नहीं मिला") }
    }

    private fun handlePicked(u: Uri, install: Boolean) = io.execute {
        val d = dadb
        if (d == null) { say("पहले TV से Connect करो"); return@execute }
        try {
            var name = "file.bin"
            contentResolver.query(u, null, null, null, null)?.use { cur ->
                val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && cur.moveToFirst()) name = cur.getString(i) ?: name
            }
            val f = File(cacheDir, name.replace("/", "_"))
            contentResolver.openInputStream(u)?.use { ins -> f.outputStream().use { o -> ins.copyTo(o) } }
            if (install) {
                say("install हो रहा है: $name")
                d.install(f)
                say("install हो गया: $name")
            } else {
                d.push(f, "/sdcard/Download/${f.name}")
                say("भेज दिया: /sdcard/Download/${f.name}")
            }
            f.delete()
        } catch (e: Exception) {
            say("फेल: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun downloadToTv(url: String) = io.execute {
        val d = dadb
        if (d == null) { say("पहले TV से Connect करो"); return@execute }
        try {
            say("डाउनलोड हो रहा है...")
            val name = url.substringBefore('?').substringAfterLast('/').ifEmpty { "download.bin" }
            val f = File(cacheDir, name)
            java.net.URL(url).openStream().use { ins -> f.outputStream().use { o -> ins.copyTo(o) } }
            d.push(f, "/sdcard/Download/$name")
            say("TV में भेज दिया: /sdcard/Download/$name")
            f.delete()
        } catch (e: Exception) {
            say("डाउनलोड फेल: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ================= Apps =================
    private fun launch(pkg: String) {
        say("खोल रहा हूँ: $pkg")
        sh("monkey -p $pkg -c android.intent.category.LAUNCHER 1") {
            if (it.contains("No activities")) sh("monkey -p $pkg -c android.intent.category.LEANBACK_LAUNCHER 1") { r ->
                if (r.contains("No activities")) say("ऐप नहीं मिला: $pkg")
            }
        }
    }

    private fun launchAlias(id: String) {
        val a = APPS[id] ?: return
        launch(a.pkgs.firstOrNull { it in installed } ?: a.pkgs.first())
    }

    private fun loadApps(render: Boolean = true) =
        sh("pm list packages -3; echo ---; pm list packages") { out ->
            val parts = out.split("---")
            fun pk(s: String) = s.lines().map { it.trim().removePrefix("package:") }.filter { it.isNotEmpty() }
            thirdParty = pk(parts[0])
            installed.clear()
            installed.addAll(pk(parts.getOrElse(1) { "" }))
            if (render) renderApps()
        }

    private fun renderApps() {
        if (!::appList.isInitialized) return
        appList.removeAllViews()
        val f = search.text.toString().trim().lowercase()
        val extra = installed.filter { p -> listOf("browser", "chrome", "settings").any { p.contains(it) } }
        val list = (thirdParty + extra).distinct().filter { f.isEmpty() || it.lowercase().contains(f) }.take(200)
        for (p in list) {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = shape(pal.card, 14)
                setPadding(dp(12), dp(6), dp(8), dp(6))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
            }
            c.addView(label(p, 13f, pal.text), LinearLayout.LayoutParams(0, -2, 1f))
            c.addView(mini("Open", pal.accent, onAccent) { launch(p) })
            c.addView(mini("Stop") { sh("am force-stop $p"); say("बंद किया: $p") })
            appList.addView(c)
        }
        if (list.isEmpty()) appList.addView(label("कोई ऐप नहीं मिला। पहले TV से Connect करो।", 14f, pal.sub))
    }

    // ================= RAM / Close =================
    private fun fmt(b: Long): String =
        if (b >= (1L shl 30)) String.format("%.1f GB", b / 1073741824.0) else "${b shr 20} MB"

    private fun pollRam(full: Boolean) {
        val d = dadb ?: return
        poll.execute {
            try {
                val m = d.shell("cat /proc/meminfo").output
                fun kb(k: String) = Regex("$k:\\s+(\\d+)").find(m)?.groupValues?.get(1)?.toLong() ?: 0L
                val total = kb("MemTotal")
                var avail = kb("MemAvailable")
                if (avail == 0L) avail = kb("MemFree") + kb("Cached")
                val used = total - avail
                val pct = if (total > 0) used * 100f / total else 0f
                ui.post {
                    ramHistory.add(pct)
                    if (ramHistory.size > 40) ramHistory.removeAt(0)
                    ramBig.text = "${used / 1024} / ${total / 1024} MB  (${pct.toInt()}%)"
                    ramSub.text = "खाली ${avail / 1024} MB  •  Cached ${kb("Cached") / 1024} MB"
                    ramChart.data = ramHistory.toList()
                }
                if (full) {
                    try {
                        val df = d.shell("df /data").output
                        val ln = df.lines().drop(1).firstOrNull { it.isNotBlank() }
                        val tk = ln?.trim()?.split(Regex("\\s+"))
                        val tot = tk?.getOrNull(1)?.toLongOrNull()
                        val usd = tk?.getOrNull(2)?.toLongOrNull()
                        if (tot != null && usd != null && tot > 0) {
                            ui.post {
                                storTv.text = "इस्तेमाल ${fmt(usd * 1024)} / ${fmt(tot * 1024)}"
                                storBar.fraction = usd.toFloat() / tot.toFloat()
                            }
                        }
                    } catch (_: Exception) {}
                    refreshTop()
                }
            } catch (_: Exception) {}
        }
    }

    private fun refreshTop() {
        val d = dadb ?: return
        poll.execute {
            try {
                val out = d.shell("dumpsys meminfo").output
                val rx = Regex("^\\s*([\\d,]+)\\s*[kK]B?:\\s+(\\S+)\\s+\\(pid", RegexOption.MULTILINE)
                val rows = rx.findAll(out)
                    .map { it.groupValues[1].replace(",", "").toLong() / 1024 to it.groupValues[2] }
                    .distinctBy { it.second }.take(15).toList()
                ui.post { topProcs = rows; renderTop() }
            } catch (_: Exception) {}
        }
    }

    private fun renderTop() {
        if (::ramApps.isInitialized) {
            ramApps.removeAllViews()
            if (topProcs.isEmpty()) ramApps.addView(label("डेटा नहीं मिला (dumpsys पढ़ नहीं पाया)", 13f, pal.sub))
            val mx = (topProcs.maxOfOrNull { it.first } ?: 1L).coerceAtLeast(1L)
            for ((m, n) in topProcs.take(10)) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                r.addView(label(n, 12f, pal.text), LinearLayout.LayoutParams(0, -2, 1f))
                r.addView(label("$m MB", 12f, pal.sub, true))
                ramApps.addView(r)
                ramApps.addView(BarView(this).apply {
                    fillColor = pal.accent; fraction = m.toFloat() / mx.toFloat()
                    layoutParams = LinearLayout.LayoutParams(-1, dp(7)).apply { topMargin = dp(2); bottomMargin = dp(8) }
                })
            }
        }
        if (::closeList.isInitialized) {
            closeList.removeAllViews()
            val protectedPk = setOf("com.android.systemui")
            val rows = topProcs.map { it.first to it.second.substringBefore(':') }
                .filter { it.second.contains('.') && it.second !in protectedPk }
                .distinctBy { it.second }
            if (rows.isEmpty()) closeList.addView(label("लिस्ट खाली है। Refresh दबाओ (TV से Connect होना चाहिए)।", 13f, pal.sub))
            for ((m, pk) in rows) {
                val r = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    background = shape(pal.btn, 12)
                    setPadding(dp(12), dp(4), dp(6), dp(4))
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) }
                }
                val t = col()
                t.addView(label(pk, 12f, pal.text))
                t.addView(label("$m MB", 11f, pal.sub))
                r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
                r.addView(mini("बंद करो", Color.parseColor("#C62828"), Color.WHITE) {
                    sh("am force-stop $pk")
                    say("बंद किया: $pk")
                    topProcs = topProcs.filter { it.second.substringBefore(':') != pk }
                    renderTop()
                })
                closeList.addView(r)
            }
        }
    }

    private fun refreshPhone() {
        try {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val usedR = mi.totalMem - mi.availMem
            phoneRam.text = "RAM: ${fmt(usedR)} / ${fmt(mi.totalMem)} इस्तेमाल  •  खाली ${fmt(mi.availMem)}"
            phoneRamBar.fraction = usedR.toFloat() / mi.totalMem.toFloat()
            val st = StatFs(Environment.getDataDirectory().path)
            val usedS = st.totalBytes - st.availableBytes
            phoneStor.text = "Storage: ${fmt(usedS)} / ${fmt(st.totalBytes)} इस्तेमाल  •  खाली ${fmt(st.availableBytes)}"
            phoneStorBar.fraction = usedS.toFloat() / st.totalBytes.toFloat()
        } catch (_: Exception) {}
    }

    // ================= Voice =================
    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        try { startActivityForResult(i, 7) } catch (e: Exception) { say("वॉइस सपोर्ट नहीं मिला") }
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (c != RESULT_OK) return
        if (r == 7) {
            d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { voice(it) }
        } else if (r == 8 || r == 9) {
            val u = d?.data ?: return
            handlePicked(u, r == 8)
        }
    }

    private fun voice(text: String) {
        val t = text.lowercase()
        say("सुना: $text")
        val cmds = listOf(
            listOf("volume up", "वॉल्यूम बढ़ा", "आवाज़ बढ़ा", "आवाज बढ़ा") to 24,
            listOf("volume down", "वॉल्यूम कम", "आवाज़ कम", "आवाज कम") to 25,
            listOf("mute", "म्यूट") to 164,
            listOf("home", "होम") to 3,
            listOf("back", "पीछे", "वापस") to 4
        )
        cmds.firstOrNull { (w, _) -> w.any { t.contains(it) } }?.let { key(it.second); return }
        APPS.entries.firstOrNull { (_, a) -> a.words.any { t.contains(it) } }?.let { launchAlias(it.key); return }
        val hit = installed.firstOrNull { t.contains(it.substringAfterLast('.').lowercase()) }
        if (hit != null) launch(hit) else say("समझ नहीं आया: $text")
    }

    // ================= Scan =================
    private fun scan() {
        say("TV ढूँढ रहा हूँ...")
        io.execute {
            val prefixes = NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.interfaceAddresses }
                .mapNotNull { (it.address as? Inet4Address)?.takeIf { a -> !a.isLoopbackAddress }?.hostAddress }
                .map { it.substringBeforeLast('.') }
                .distinct()
            val found = ConcurrentLinkedQueue<String>()
            val pool = Executors.newFixedThreadPool(64)
            for (p in prefixes) for (i in 1..254) pool.execute {
                val h = "$p.$i"
                try {
                    Socket().use { it.connect(InetSocketAddress(h, 5555), 400) }
                    found.add(h)
                } catch (_: Exception) {}
            }
            pool.shutdown()
            pool.awaitTermination(30, TimeUnit.SECONDS)
            val ip = found.firstOrNull()
            if (ip == null) {
                say("TV नहीं मिला। हॉटस्पॉट/WiFi ON है? ADB ON है?")
            } else {
                prefs.edit().putString("ip", ip).apply()
                ui.post { ipBox.setText(ip) }
                connectRetry(ip)
            }
        }
    }
}
