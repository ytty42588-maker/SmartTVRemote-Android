package dadb;

public final class AdbShellResponse {
    private final String output;
    private final String errorOutput;
    private final int exitCode;

    public AdbShellResponse(String output, String errorOutput, int exitCode) {
        this.output = output;
        this.errorOutput = errorOutput;
        this.exitCode = exitCode;
    }

    public String getOutput() { return output; }
    public String getErrorOutput() { return errorOutput; }
    public int getExitCode() { return exitCode; }
}
