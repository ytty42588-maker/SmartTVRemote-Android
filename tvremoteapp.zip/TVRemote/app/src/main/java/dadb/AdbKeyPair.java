package dadb;

import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.spec.PKCS8EncodedKeySpec;

/** ADB RSA key: private key (PKCS8 PEM) + Android-format public key. */
public final class AdbKeyPair {
    private static final byte[] SHA1_PREFIX = new byte[]{
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14};

    private final PrivateKey privateKey;
    private final byte[] publicPayload;

    private AdbKeyPair(PrivateKey privateKey, byte[] publicPayload) {
        this.privateKey = privateKey;
        this.publicPayload = publicPayload;
    }

    public static void generate(File priv, File pub) throws Exception {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        String b64 = Base64.encodeToString(kp.getPrivate().getEncoded(), Base64.NO_WRAP);
        StringBuilder pem = new StringBuilder("-----BEGIN PRIVATE KEY-----\n");
        for (int i = 0; i < b64.length(); i += 64) {
            pem.append(b64, i, Math.min(b64.length(), i + 64)).append('\n');
        }
        pem.append("-----END PRIVATE KEY-----\n");
        writeFile(priv, pem.toString().getBytes("UTF-8"));
        AdbKeyPair k = read(priv, pub);
        writeFile(pub, k.publicPayload);
    }

    public static AdbKeyPair read(File priv, File pub) throws Exception {
        String pem = new String(readFile(priv), "UTF-8");
        String b64 = pem.replaceAll("-----[A-Z ]+-----", "").replaceAll("\\s", "");
        byte[] der = Base64.decode(b64, Base64.DEFAULT);
        PrivateKey pk = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(der));
        if (!(pk instanceof RSAPrivateCrtKey)) throw new IOException("bad key type");
        RSAPrivateCrtKey crt = (RSAPrivateCrtKey) pk;
        return new AdbKeyPair(pk, androidPublicKey(crt.getModulus(), crt.getPublicExponent()));
    }

    byte[] sign(byte[] token) throws Exception {
        Signature s = Signature.getInstance("NONEwithRSA");
        s.initSign(privateKey);
        byte[] data = new byte[SHA1_PREFIX.length + token.length];
        System.arraycopy(SHA1_PREFIX, 0, data, 0, SHA1_PREFIX.length);
        System.arraycopy(token, 0, data, SHA1_PREFIX.length, token.length);
        s.update(data);
        return s.sign();
    }

    /** base64(mincrypt RSAPublicKey) + " name" + NUL */
    byte[] publicKeyPayload() { return publicPayload; }

    private static byte[] androidPublicKey(BigInteger n, BigInteger e) throws Exception {
        final int words = 64; // 2048 bit
        BigInteger r32 = BigInteger.ONE.shiftLeft(32);
        int n0inv = r32.subtract(n.mod(r32).modInverse(r32)).intValue();
        BigInteger rr = BigInteger.ONE.shiftLeft(2048 * 2).mod(n);
        ByteBuffer bb = ByteBuffer.allocate(4 + 4 + words * 4 + words * 4 + 4).order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(words);
        bb.putInt(n0inv);
        for (int i = 0; i < words; i++) bb.putInt(n.shiftRight(32 * i).intValue());
        for (int i = 0; i < words; i++) bb.putInt(rr.shiftRight(32 * i).intValue());
        bb.putInt(e.intValue());
        String s = Base64.encodeToString(bb.array(), Base64.NO_WRAP) + " tvremote@android";
        byte[] raw = s.getBytes("UTF-8");
        byte[] out = new byte[raw.length + 1];
        System.arraycopy(raw, 0, out, 0, raw.length);
        return out;
    }

    private static byte[] readFile(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return bo.toByteArray();
        }
    }

    private static void writeFile(File f, byte[] data) throws IOException {
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
    }
}
