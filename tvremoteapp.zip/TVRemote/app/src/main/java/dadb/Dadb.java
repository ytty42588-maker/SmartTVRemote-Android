package dadb;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;

/**
 * Minimal ADB client (legacy protocol). Works with very old adbd (Android 5.x) that sends no
 * "features" in its banner and has no shell_v2 -- the case where dadb 1.2.7 fails.
 * One stream at a time; all operations are serialized.
 */
public final class Dadb implements Closeable {
    private static final int A_CNXN = 0x4e584e43;
    private static final int A_AUTH = 0x48545541;
    private static final int A_OPEN = 0x4e45504f;
    private static final int A_OKAY = 0x59414b4f;
    private static final int A_CLSE = 0x45534c43;
    private static final int A_WRTE = 0x45545257;
    private static final int VERSION = 0x01000000;
    private static final int MY_MAXDATA = 4096;

    private static final class Msg {
        int cmd, arg0, arg1;
        byte[] data;
    }

    private final Socket socket;
    private final DataInputStream in;
    private final OutputStream out;
    private int maxData = 4096;
    private int nextId = 1;
    private volatile boolean closed = false;

    private Dadb(Socket s) throws IOException {
        this.socket = s;
        this.in = new DataInputStream(s.getInputStream());
        this.out = s.getOutputStream();
    }

    public static Dadb create(String host, int port, AdbKeyPair keys) throws IOException {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, port), 5000);
            s.setTcpNoDelay(true);
            s.setSoTimeout(45000);
            Dadb d = new Dadb(s);
            d.handshake(keys);
            s.setSoTimeout(60000);
            return d;
        } catch (IOException | RuntimeException e) {
            try { s.close(); } catch (IOException ignored) { }
            throw e;
        }
    }

    public boolean isClosed() { return closed || socket.isClosed(); }

    @Override
    public void close() {
        closed = true;
        try { socket.close(); } catch (IOException ignored) { }
    }

    // ---------------- wire ----------------
    private synchronized void send(int cmd, int arg0, int arg1, byte[] data) throws IOException {
        if (data == null) data = new byte[0];
        int sum = 0;
        for (byte b : data) sum += (b & 0xff);
        ByteBuffer h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        h.putInt(cmd).putInt(arg0).putInt(arg1).putInt(data.length).putInt(sum).putInt(cmd ^ 0xffffffff);
        out.write(h.array());
        if (data.length > 0) out.write(data);
        out.flush();
    }

    private Msg read() throws IOException {
        byte[] hb = new byte[24];
        in.readFully(hb);
        ByteBuffer h = ByteBuffer.wrap(hb).order(ByteOrder.LITTLE_ENDIAN);
        Msg m = new Msg();
        m.cmd = h.getInt();
        m.arg0 = h.getInt();
        m.arg1 = h.getInt();
        int len = h.getInt();
        h.getInt(); // checksum (ignored)
        int magic = h.getInt();
        if (magic != (m.cmd ^ 0xffffffff)) throw new IOException("ADB protocol error (bad magic)");
        if (len < 0 || len > 1024 * 1024) throw new IOException("ADB protocol error (bad length)");
        m.data = new byte[len];
        if (len > 0) in.readFully(m.data);
        return m;
    }

    private void handshake(AdbKeyPair keys) throws IOException {
        send(A_CNXN, VERSION, MY_MAXDATA, "host::\0".getBytes(StandardCharsets.UTF_8));
        boolean sentSig = false, sentPub = false;
        while (true) {
            Msg m = read();
            if (m.cmd == A_CNXN) {
                // banner may or may not have "features=" -- we do not need it
                int md = m.arg1;
                if (md < 256) md = 4096;
                maxData = Math.min(md, 64 * 1024);
                return;
            } else if (m.cmd == A_AUTH && m.arg0 == 1) {
                if (!sentSig) {
                    try {
                        send(A_AUTH, 2, 0, keys.sign(m.data));
                    } catch (IOException e) {
                        throw e;
                    } catch (Exception e) {
                        throw new IOException("key sign failed: " + e);
                    }
                    sentSig = true;
                } else if (!sentPub) {
                    send(A_AUTH, 3, 0, keys.publicKeyPayload());
                    sentPub = true;
                } else {
                    throw new IOException("TV ने key reject कर दी");
                }
            } else if (m.cmd == A_CLSE || m.cmd == A_OKAY || m.cmd == A_WRTE) {
                // stale message from earlier session; ignore
            } else {
                throw new IOException("unexpected reply during connect: 0x" + Integer.toHexString(m.cmd));
            }
        }
    }

    // ---------------- streams ----------------
    private final class Stream {
        final int localId;
        final int remoteId;
        private final ArrayDeque<byte[]> pending = new ArrayDeque<>();
        private byte[] cur = new byte[0];
        private int pos = 0;
        boolean remoteClosed = false;

        Stream(int l, int r) { localId = l; remoteId = r; }

        void write(byte[] data) throws IOException {
            int off = 0;
            while (off < data.length) {
                int n = Math.min(maxData, data.length - off);
                byte[] chunk = new byte[n];
                System.arraycopy(data, off, chunk, 0, n);
                send(A_WRTE, localId, remoteId, chunk);
                off += n;
                waitOkay();
            }
        }

        private void waitOkay() throws IOException {
            while (true) {
                Msg m = Dadb.this.read();
                if (m.arg1 != localId) continue;
                if (m.cmd == A_OKAY) return;
                if (m.cmd == A_CLSE) { remoteClosed = true; throw new IOException("TV ने stream बंद कर दी"); }
                if (m.cmd == A_WRTE) {
                    send(A_OKAY, localId, remoteId, null);
                    pending.add(m.data);
                }
            }
        }

        /** next chunk, or null when remote closed */
        byte[] readChunk() throws IOException {
            if (!pending.isEmpty()) return pending.poll();
            if (remoteClosed) return null;
            while (true) {
                Msg m = Dadb.this.read();
                if (m.arg1 != localId) continue;
                if (m.cmd == A_WRTE) {
                    send(A_OKAY, localId, remoteId, null);
                    return m.data;
                }
                if (m.cmd == A_CLSE) {
                    remoteClosed = true;
                    try { send(A_CLSE, localId, remoteId, null); } catch (IOException ignored) { }
                    return null;
                }
            }
        }

        byte[] readExact(int n) throws IOException {
            byte[] res = new byte[n];
            int got = 0;
            while (got < n) {
                if (pos >= cur.length) {
                    byte[] c = readChunk();
                    if (c == null) throw new IOException("stream अचानक बंद हो गई");
                    cur = c;
                    pos = 0;
                }
                int k = Math.min(n - got, cur.length - pos);
                System.arraycopy(cur, pos, res, got, k);
                pos += k;
                got += k;
            }
            return res;
        }

        void close() {
            if (remoteClosed) return;
            try { send(A_CLSE, localId, remoteId, null); } catch (IOException ignored) { }
            remoteClosed = true;
        }
    }

    private Stream open(String service) throws IOException {
        int id = nextId++;
        send(A_OPEN, id, 0, (service + "\0").getBytes(StandardCharsets.UTF_8));
        while (true) {
            Msg m = read();
            if (m.arg1 != id) continue;
            if (m.cmd == A_OKAY) return new Stream(id, m.arg0);
            if (m.cmd == A_CLSE) throw new IOException("TV ने service मना कर दी: " + service);
        }
    }

    // ---------------- API ----------------
    public synchronized AdbShellResponse shell(String command) throws IOException {
        try {
            Stream st = open("shell:" + command);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] c;
            while ((c = st.readChunk()) != null) bo.write(c);
            String s = new String(bo.toByteArray(), StandardCharsets.UTF_8).replace("\r\n", "\n");
            return new AdbShellResponse(s, "", 0);
        } catch (IOException e) {
            if (e instanceof java.net.SocketTimeoutException) close();
            throw e;
        }
    }

    public synchronized void push(File file, String remotePath) throws IOException {
        Stream st = open("sync:");
        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] spec = (remotePath + ",33206").getBytes(StandardCharsets.UTF_8);
            ByteBuffer h = ByteBuffer.allocate(8 + spec.length).order(ByteOrder.LITTLE_ENDIAN);
            h.put("SEND".getBytes(StandardCharsets.US_ASCII)).putInt(spec.length).put(spec);
            st.write(h.array());
            byte[] buf = new byte[32 * 1024];
            int n;
            while ((n = fin.read(buf)) > 0) {
                ByteBuffer d = ByteBuffer.allocate(8 + n).order(ByteOrder.LITTLE_ENDIAN);
                d.put("DATA".getBytes(StandardCharsets.US_ASCII)).putInt(n).put(buf, 0, n);
                st.write(d.array());
            }
            ByteBuffer done = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
            done.put("DONE".getBytes(StandardCharsets.US_ASCII)).putInt((int) (file.lastModified() / 1000));
            st.write(done.array());
            byte[] resp = st.readExact(8);
            String id = new String(resp, 0, 4, StandardCharsets.US_ASCII);
            if (!id.equals("OKAY")) {
                int len = ByteBuffer.wrap(resp, 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
                String msg = "";
                if (len > 0 && len < 4096) msg = new String(st.readExact(len), StandardCharsets.UTF_8);
                throw new IOException("push failed: " + msg);
            }
        } finally {
            st.close();
        }
    }

    public void install(File apk) throws IOException {
        String tmp = "/data/local/tmp/_tvr_" + System.currentTimeMillis() + ".apk";
        push(apk, tmp);
        String out;
        try {
            out = shell("pm install -r \"" + tmp + "\"").getOutput();
        } finally {
            try { shell("rm -f \"" + tmp + "\""); } catch (IOException ignored) { }
        }
        if (!out.contains("Success")) throw new IOException(out.trim().isEmpty() ? "install failed" : out.trim());
    }
}
